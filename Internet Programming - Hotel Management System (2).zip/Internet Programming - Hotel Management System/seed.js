const mongoose = require('mongoose');
const connectDB = require('./src/db');
const seedDatabase = require('./src/seed/seedDatabase');

async function runSeeder() {
  try {
    await connectDB();
    console.log('Seeding database...');
    const result = await seedDatabase();
    console.log('Seed complete:', result);
    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
}

runSeeder();
