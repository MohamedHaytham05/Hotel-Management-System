import { useEffect } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";
import HomePage from "./Pages/HomePage";
import NotificationHistoryPage from './Pages/NotificationHistoryPage';
import { NotificationProvider } from "./Context/NotificationContext";
import TermsPage from "./Pages/TermsPage";
import About from "./Pages/About";
import Reviews from "./Pages/Reviews";
import Admin from "./Pages/Admin";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import Hotels from "./Pages/Hotels";
import Book from "./Pages/Book";
import Profile from "./Pages/Profile";
import { useAuth } from "./Context/AuthContext";

function ProtectedRoute({ children }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="p-10 text-center">Loading...</div>;
  }

  return isAuthenticated ? children : <Navigate to="/Login" replace />;
}

function AdminRoute({ children }) {
  const { isAdmin, isLoading } = useAuth();

  if (isLoading) {
    return <div className="p-10 text-center">Loading...</div>;
  }

  return isAdmin ? children : <Navigate to="/" replace />;
}

function GuestOnlyRoute({ children }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="p-10 text-center">Loading...</div>;
  }

  return isAuthenticated ? <Navigate to="/Profile" replace /> : children;
}

function App() {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <NotificationProvider>
      <>
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/About" element={<About />} />
            <Route
              path="/Login"
              element={
                <GuestOnlyRoute>
                  <Login />
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/signup"
              element={
                <GuestOnlyRoute>
                  <Signup />
                </GuestOnlyRoute>
              }
            />
            <Route
              path="/notification-history"
              element={
                <ProtectedRoute>
                  <NotificationHistoryPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/Reviews"
              element={
                <ProtectedRoute>
                  <Reviews />
                </ProtectedRoute>
              }
            />
            <Route
              path="/Hotels"
              element={
                <ProtectedRoute>
                  <Hotels />
                </ProtectedRoute>
              }
            />
            <Route
              path="/book"
              element={
                <ProtectedRoute>
                  <Book />
                </ProtectedRoute>
              }
            />
            <Route
              path="/Profile"
              element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <AdminRoute>
                  <Admin />
                </AdminRoute>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </>
    </NotificationProvider>
  );
}

export default App;
