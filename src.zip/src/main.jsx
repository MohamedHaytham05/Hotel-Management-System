import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from "./App.jsx";
import './style.css';
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./Context/AuthContext";
createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <StrictMode>
      <AuthProvider>
        <App/>
      </AuthProvider>
    </StrictMode>
  </BrowserRouter>
)
