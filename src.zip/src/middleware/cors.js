const corsOptions = {
  credentials: true,
  origin: function (origin, callback) {

    if (!origin) return callback(null, true);

    if (/^https?:\/\/localhost(:[0-9]+)?$/.test(origin)) {
      return callback(null, origin);
    }

    callback(new Error('Not allowed by CORS'));
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

module.exports = corsOptions;
