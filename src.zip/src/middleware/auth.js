const jwt = require('jsonwebtoken');

const protect = async (req, res, next) => {
  try {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ message: 'Not authenticated - no token' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-super-secret-jwt-key-change-in-prod');
    req.user = decoded;

    next();
  } catch (error) {
    res.status(401).json({ message: 'Not authenticated - invalid token' });
  }
};

const adminOnly = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

module.exports = { protect, adminOnly };
