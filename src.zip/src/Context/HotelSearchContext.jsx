import { createContext, useContext, useMemo, useState } from "react";

const HotelSearchContext = createContext(null);

export function HotelSearchProvider({ children }) {
  const [selectedCity, setSelectedCity] = useState("");

  const value = useMemo(
    () => ({
      selectedCity,
      setSelectedCity,
    }),
    [selectedCity]
  );

  return (
    <HotelSearchContext.Provider value={value}>
      {children}
    </HotelSearchContext.Provider>
  );
}

export function useHotelSearch() {
  const context = useContext(HotelSearchContext);

  if (!context) {
    throw new Error("useHotelSearch must be used within a HotelSearchProvider");
  }

  return context;
}
