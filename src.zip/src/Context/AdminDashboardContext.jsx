import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiFetch } from "../lib/api";

const AdminDashboardContext = createContext(null);

const stats = [
  { icon: "Hotel", label: "Total Hotels", value: "24", change: "+12%", color: "bg-blue-500" },
  { icon: "BedDouble", label: "Total Rooms", value: "342", change: "+8%", color: "bg-green-500" },
  { icon: "Users", label: "Active Bookings", value: "156", change: "+23%", color: "bg-purple-500" },
  { icon: "DollarSign", label: "Monthly Revenue", value: "$127K", change: "+18%", color: "bg-yellow-500" },
];

const revenueData = {
  "7days": [
    { day: "Mon", amount: 4500 },
    { day: "Tue", amount: 5200 },
    { day: "Wed", amount: 4800 },
    { day: "Thu", amount: 6100 },
    { day: "Fri", amount: 7800 },
    { day: "Sat", amount: 9200 },
    { day: "Sun", amount: 6700 },
  ],
  "30days": [
    { day: "Week 1", amount: 28500 },
    { day: "Week 2", amount: 31200 },
    { day: "Week 3", amount: 29800 },
    { day: "Week 4", amount: 34100 },
  ],
  "3months": [
    { day: "Jan", amount: 98500 },
    { day: "Feb", amount: 102300 },
    { day: "Mar", amount: 127800 },
  ],
};

const bookingData = {
  "today": [
    { status: "Completed", count: 12, color: "bg-green-500" },
    { status: "Pending", count: 5, color: "bg-yellow-500" },
    { status: "Cancelled", count: 2, color: "bg-red-500" },
    { status: "In Progress", count: 8, color: "bg-blue-500" },
  ],
  "week": [
    { status: "Completed", count: 98, color: "bg-green-500" },
    { status: "Pending", count: 32, color: "bg-yellow-500" },
    { status: "Cancelled", count: 15, color: "bg-red-500" },
    { status: "In Progress", count: 45, color: "bg-blue-500" },
  ],
  "month": [
    { status: "Completed", count: 356, color: "bg-green-500" },
    { status: "Pending", count: 98, color: "bg-yellow-500" },
    { status: "Cancelled", count: 42, color: "bg-red-500" },
    { status: "In Progress", count: 156, color: "bg-blue-500" },
  ],
};

export function AdminDashboardProvider({ children }) {
  const [revenuePeriod, setRevenuePeriod] = useState("7days");
  const [bookingPeriod, setBookingPeriod] = useState("month");
  const [recentActivity, setRecentActivity] = useState([]);
  const [activityLoading, setActivityLoading] = useState(true);

  useEffect(() => {
    async function loadActivities() {
      try {
        const activities = await apiFetch('/api/admin/activities');
        setRecentActivity(activities || []);
      } catch (error) {
        console.error('Failed to load activities:', error);
        setRecentActivity([]);
      } finally {
        setActivityLoading(false);
      }
    }

    loadActivities();
  }, []);

  const value = useMemo(
    () => ({
      stats,
      revenueData,
      revenuePeriod,
      setRevenuePeriod,
      bookingData,
      bookingPeriod,
      setBookingPeriod,
      recentActivity,
      activityLoading,
    }),
    [bookingPeriod, revenuePeriod, recentActivity, activityLoading]
  );

  return (
    <AdminDashboardContext.Provider value={value}>
      {children}
    </AdminDashboardContext.Provider>
  );
}

export function useAdminDashboard() {
  const context = useContext(AdminDashboardContext);

  if (!context) {
    throw new Error("useAdminDashboard must be used within an AdminDashboardProvider");
  }

  return context;
}
