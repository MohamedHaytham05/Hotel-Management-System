import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiFetch } from "../lib/api";

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [markingAllRead, setMarkingAllRead] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function loadNotifications() {
      try {
        const data = await apiFetch("/api/notifications");
        if (isMounted) {
          setNotifications(data);
        }
      } catch {
        if (isMounted) {
          setNotifications([]);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    loadNotifications();

    return () => {
      isMounted = false;
    };
  }, []);

  const value = useMemo(
    () => ({
      notifications,
      isLoading,
      markingAllRead,
      unreadCount: notifications.filter((notification) => !notification.read).length,
      async addNotification(message) {
        try {
          const notification = await apiFetch("/api/notifications", {
            method: "POST",
            body: JSON.stringify({ message }),
          });
          setNotifications((current) => [notification, ...current]);
        } catch (error) {
          console.error('Failed to add notification:', error);
        }
      },
      async markAsRead(id) {
        try {
          const updatedNotification = await apiFetch(`/api/notifications/${id}`, {
            method: "PUT",
            body: JSON.stringify({ read: true }),
          });
          setNotifications((current) =>
            current.map((notification) =>
              notification._id === id ? updatedNotification : notification
            )
          );
        } catch (error) {
          console.error('Failed to mark as read:', error);
        }
      },
      async markAllAsRead() {
        if (markingAllRead) return;
        setMarkingAllRead(true);
        try {
          const unreadNotifications = notifications.filter((notification) => !notification.read);
          const updatedNotifications = await Promise.all(
            unreadNotifications.map((notification) =>
              apiFetch(`/api/notifications/${notification._id}`, {
                method: "PUT",
                body: JSON.stringify({ read: true }),
              })
            )
          );
          const updatedMap = new Map(updatedNotifications.map((notification) => [notification._id, notification]));
          setNotifications((current) =>
            current.map((notification) => updatedMap.get(notification._id) || notification)
          );
        } catch (error) {
          console.error('Failed to mark all as read:', error);

          const data = await apiFetch("/api/notifications");
          setNotifications(data);
        } finally {
          setMarkingAllRead(false);
        }
      },
      async deleteNotification(id) {
        try {
          await apiFetch(`/api/notifications/${id}`, {
            method: "DELETE",
          });
          setNotifications((current) =>
            current.filter((notification) => notification._id !== id)
          );
        } catch (error) {
          console.error('Failed to delete notification:', error);
        }
      },
      clearNotifications() {
        setNotifications([]);
      },
      resetNotifications() {
        setNotifications([]);
      },
    }),
    [notifications, isLoading, markingAllRead]
  );

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);

  if (!context) {
    throw new Error("useNotifications must be used within a NotificationProvider");
  }

  return context;
}
