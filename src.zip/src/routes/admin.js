const express = require('express');
const { protect, adminOnly: requireAdmin } = require('../middleware/auth');
const activityController = require('../controllers/activityController');
const { getAdminStats, getBookingChartData, getRevenueChartData } = require('../controllers/adminController');

const router = express.Router();

router.use(protect, requireAdmin);

router.get('/stats', getAdminStats);
router.get('/charts/bookings', getBookingChartData);
router.get('/charts/revenue', getRevenueChartData);
router.get('/activities', activityController.getRecentActivities);

module.exports = router;
