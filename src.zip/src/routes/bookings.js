const express = require('express');
const { getBookings, createBooking, getBooking, cancelBooking, deleteBooking, updateBookingStatus } = require('../controllers/bookingsController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.get('/', getBookings);
router.post('/', createBooking);
router.put('/:id', updateBookingStatus);
router.delete('/:id', deleteBooking);

module.exports = router;
