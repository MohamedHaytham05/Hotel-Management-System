const express = require('express');
const { register, login, getMe, updateMe, logout } = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const { registerRules, loginRules } = require('../middleware/validators');

const router = express.Router();

router.post('/register', registerRules, register);
router.post('/login', loginRules, login);
router.post('/logout', protect, logout);

router.get('/me', protect, getMe);
router.put('/me', protect, updateMe);

module.exports = router;
