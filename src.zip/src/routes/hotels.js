const express = require('express');
const { getAllHotels, getHotelById, createHotel, updateHotel, deleteHotel } = require('../controllers/hotelsController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllHotels);
router.get('/:id', getHotelById);

router.post('/', protect, adminOnly, createHotel);
router.put('/:id', protect, adminOnly, updateHotel);
router.delete('/:id', protect, adminOnly, deleteHotel);

module.exports = router;
