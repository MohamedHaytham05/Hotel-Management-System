const express = require('express');
const { getReviews, createReview, updateReview, deleteReview } = require('../controllers/reviewsController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, getReviews);
router.post('/', protect, createReview);
router.put('/:id', protect, updateReview);
router.delete('/:id', protect, deleteReview);

module.exports = router;
