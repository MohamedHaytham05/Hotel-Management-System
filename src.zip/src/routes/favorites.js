const express = require('express');
const { toggleFavorite, getFavorites, deleteFavorite } = require('../controllers/favoritesController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.post('/toggle', protect, toggleFavorite);
router.get('/', protect, getFavorites);
router.delete('/:id', protect, deleteFavorite);

module.exports = router;
