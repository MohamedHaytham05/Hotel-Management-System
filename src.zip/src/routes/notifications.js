const express = require('express');
const { getNotifications, createNotification, updateNotification, deleteNotification } = require('../controllers/notificationsController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, getNotifications);

router.post('/', protect, adminOnly, createNotification);

router.put('/:id', protect, updateNotification);
router.delete('/:id', protect, deleteNotification);

module.exports = router;
