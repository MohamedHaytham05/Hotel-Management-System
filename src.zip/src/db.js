const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const seedDatabase = require('./seed/seedDatabase');

function readRawMongoUriFromEnvFile() {
  try {
    const envPath = path.resolve(__dirname, '..', '.env');
    const envContents = fs.readFileSync(envPath, 'utf8');
    const firstValueLine = envContents
      .split(/\r?\n/)
      .map((line) => line.trim())
      .find((line) => line && !line.startsWith('#'));

    if (
      firstValueLine &&
      (firstValueLine.startsWith('mongodb://') || firstValueLine.startsWith('mongodb+srv://'))
    ) {
      return firstValueLine;
    }
  } catch {
    return undefined;
  }

  return undefined;
}

function resolveMongoUri() {
  return (
    process.env.MONGO_URI ||
    process.env.MONGODB_URI ||
    process.env.DATABASE_URL ||
    readRawMongoUriFromEnvFile()
  );
}

async function connectDB() {
  const mongoUri = resolveMongoUri();

  if (!mongoUri) {
    throw new Error(
      'MongoDB connection string is missing. Add MONGO_URI=... to .env or place the raw mongodb URI on the first line of .env.'
    );
  }

  await mongoose.connect(mongoUri, {
    serverSelectionTimeoutMS: 10000,
  });
  await seedDatabase();
  console.log('MongoDB connected successfully');
}

module.exports = connectDB;
