import { useEffect, useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import StarRating from "../Components/StarRating";
import ReviewCard from "../Components/Reviewcard";
import { apiFetch } from "../lib/api";

const reviewSchema = Yup.object({
  name: Yup.string()
    .required("Name is required")
    .matches(/^[A-Za-z\s]+$/, "Numbers and special characters are not allowed")
    .min(2, "Name must be at least 2 characters")
    .max(50, "Name cannot exceed 50 characters"),
  text: Yup.string()
    .required("Review is required")
    .test("word-count", "Review cannot exceed 250 words", (value) => {
      if (!value) return true;
      return value.trim().split(/\s+/).length <= 250;
    })
    .test("min-words", "Review must be at least 5 words", (value) => {
      if (!value) return false;
      return value.trim().split(/\s+/).length >= 5;
    }),
  rating: Yup.number()
    .required("Please select a rating")
    .min(1, "Rating is required")
    .max(5, "Rating cannot exceed 5 stars"),
  hotelId: Yup.string().required("Please select a hotel"),
});

function Reviews() {
  const [reviews, setReviews] = useState([]);
  const [hotels, setHotels] = useState([]);
  const [filterRating, setFilterRating] = useState(0);
  const [formMessage, setFormMessage] = useState("");
  const maxWords = 250;

  const formik = useFormik({
    initialValues: {
      hotelId: "",
      name: "",
      text: "",
      rating: 0,
    },
    validationSchema: reviewSchema,
    onSubmit: async (values, { resetForm, setFieldValue }) => {
      setFormMessage("");
      try {
        const newReview = await apiFetch("/api/reviews", {
          method: "POST",
          body: JSON.stringify({
            hotelId: values.hotelId,
            rating: values.rating,
            text: values.text,
          }),
        });
        setReviews((currentReviews) => [newReview, ...currentReviews]);
        setFormMessage("Review submitted successfully.");
        resetForm();
        setFieldValue("name", values.name);
      } catch (error) {
        setFormMessage(error.message);
      }
    },
  });
  const { setFieldValue } = formik;

  useEffect(() => {
    async function loadData() {
      try {
        const [reviewsData, hotelsData] = await Promise.all([
          apiFetch("/api/reviews"),
          apiFetch("/api/hotels"),
        ]);
        setReviews(reviewsData);
        setHotels(hotelsData);
      } catch {
        setReviews([]);
        setHotels([]);
      }

      try {
        const currentUser = await apiFetch("/api/auth/me");
        setFieldValue("name", currentUser.name);
      } catch {
        setFieldValue("name", "Guest User");
      }
    }

    loadData();
  }, [setFieldValue]);

  const totalReviews = reviews.length;
  const average = totalReviews > 0
    ? (reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews).toFixed(1)
    : 0;

  const ratingCounts = {
    5: reviews.filter((review) => review.rating === 5).length,
    4: reviews.filter((review) => review.rating === 4).length,
    3: reviews.filter((review) => review.rating === 3).length,
    2: reviews.filter((review) => review.rating === 2).length,
    1: reviews.filter((review) => review.rating === 1).length,
  };

  const ratingPercentages = {
    5: totalReviews ? ((ratingCounts[5] / totalReviews) * 100).toFixed(0) : 0,
    4: totalReviews ? ((ratingCounts[4] / totalReviews) * 100).toFixed(0) : 0,
    3: totalReviews ? ((ratingCounts[3] / totalReviews) * 100).toFixed(0) : 0,
    2: totalReviews ? ((ratingCounts[2] / totalReviews) * 100).toFixed(0) : 0,
    1: totalReviews ? ((ratingCounts[1] / totalReviews) * 100).toFixed(0) : 0,
  };

  const filteredReviews = filterRating === 0
    ? reviews
    : reviews.filter((review) => review.rating === filterRating);

  const currentWordCount = formik.values.text.trim() === ""
    ? 0
    : formik.values.text.trim().split(/\s+/).length;

  return (
    <div className="max-w-4xl mx-auto p-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Guest Reviews</h1>
          <p className="text-gray-600 text-lg">What our guests say about their stay</p>
        </div>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-md mb-8 text-left">
        <div className="mb-6">
          <span className="text-5xl font-bold text-gray-900">{average}</span>
          <span className="text-4xl text-yellow-400 ml-2">*</span>
          <span className="text-lg text-gray-600 ml-4">
            {totalReviews.toLocaleString()} reviews
          </span>
        </div>

        <div className="mb-6">
          {[5, 4, 3, 2, 1].map((star) => (
            <div
              key={star}
              className={`flex items-center gap-3 mb-3 p-1 rounded cursor-pointer transition-colors ${
                filterRating === star ? "bg-blue-50 border border-blue-200" : "hover:bg-gray-50"
              }`}
              onClick={() => setFilterRating(filterRating === star ? 0 : star)}
            >
              <span className="w-12 text-gray-700">{star} *</span>
              <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden max-w-md">
                <div
                  className="h-full bg-yellow-400"
                  style={{ width: `${ratingPercentages[star]}%` }}
                />
              </div>
              <span className="w-14 text-right text-gray-600">{ratingPercentages[star]}%</span>
              <span className="w-14 text-right text-gray-400">({ratingCounts[star]})</span>
            </div>
          ))}
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setFilterRating(0)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
              filterRating === 0 ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            * All
          </button>
          {[5, 4, 3, 2, 1].map((star) => (
            <button
              key={star}
              onClick={() => setFilterRating(filterRating === star ? 0 : star)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                filterRating === star ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              * {star}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4 mb-8">
        {filteredReviews.map((review) => (
          <ReviewCard key={review._id || review.id} review={review} />
        ))}
      </div>

      <div className="bg-white p-8 rounded-xl shadow-md">
        <h2 className="text-2xl font-semibold mb-6">Leave a Review</h2>
        <form onSubmit={formik.handleSubmit}>
          <div className="mb-4">
            <select
              name="hotelId"
              value={formik.values.hotelId}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 transition ${
                formik.touched.hotelId && formik.errors.hotelId
                  ? "border-red-500 focus:ring-red-200"
                  : "border-gray-300 focus:ring-blue-200"
              }`}
            >
              <option value="">Select a hotel</option>
              {hotels.map((hotel) => (
                <option key={hotel._id} value={hotel._id}>{hotel.name}</option>
              ))}
            </select>
            {formik.touched.hotelId && formik.errors.hotelId && (
              <p className="text-red-500 text-sm mt-1 flex items-center gap-1">
                <span>!</span> {formik.errors.hotelId}
              </p>
            )}
          </div>

          <div className="mb-4">
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formik.values.name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              disabled
              className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 transition ${
                formik.touched.name && formik.errors.name
                  ? "border-red-500 focus:ring-red-200"
                  : "border-gray-300 focus:ring-blue-200"
              }`}
            />
            {formik.touched.name && formik.errors.name && (
              <p className="text-red-500 text-sm mt-1 flex items-center gap-1">
                <span>!</span> {formik.errors.name}
              </p>
            )}
          </div>

          <div className="mb-4">
            <textarea
              name="text"
              placeholder="Write your review..."
              rows="5"
              value={formik.values.text}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 transition resize-none ${
                formik.touched.text && formik.errors.text
                  ? "border-red-500 focus:ring-red-200"
                  : "border-gray-300 focus:ring-blue-200"
              }`}
            />
            <div className="flex justify-between mt-2 text-sm">
              <span className="text-gray-500">Maximum {maxWords} words</span>
              <span className={currentWordCount > maxWords ? "text-red-500 font-medium" : "text-gray-500"}>
                {currentWordCount}/{maxWords} words
              </span>
            </div>

            {formik.touched.text && formik.errors.text && (
              <p className="text-red-500 text-sm mt-1 flex items-center gap-1">
                <span>!</span> {formik.errors.text}
              </p>
            )}
          </div>

          <div className="mb-6">
            <p className="text-gray-700 text-sm mb-3">Your Rating</p>
            <StarRating
              rating={formik.values.rating}
              setRating={(value) => formik.setFieldValue("rating", value)}
            />
            {formik.touched.rating && formik.errors.rating && (
              <p className="text-red-500 text-sm mt-2 flex items-center gap-1">
                <span>!</span> {formik.errors.rating}
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
          >
            Submit Review
          </button>
          {formMessage && <p className="mt-3 text-sm text-blue-600">{formMessage}</p>}
        </form>
      </div>
    </div>
  );
}

export default Reviews;
