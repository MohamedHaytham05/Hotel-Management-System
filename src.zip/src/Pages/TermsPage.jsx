import React from 'react';
import {
  Home, Calendar, CreditCard, XCircle, RefreshCw, FileText,
  Users, Shield, AlertTriangle, Globe, Lock,
  Star, ThumbsUp, Clock, DollarSign, Briefcase, Heart, Mail, Scale
} from 'lucide-react';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4 flex items-center gap-3">
          <FileText className="text-yellow-500" size={36} />
          Terms and Conditions
        </h1>
        <p className="text-gray-500 mb-8">Last updated: March 2025</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Home className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  1. Introduction
                </h2>
                <p className="text-gray-600">Welcome to Hotlio. You accept these terms and conditions by using our services and website. You are not allowed to use our services if you disagree with any of the guidelines.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Calendar className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  2. Booking Process
                </h2>
                <p className="text-gray-600">All reservations are based on the hotel&apos;s availability and confirmation. When making a reservation, you require accurate information. Hotlio serves as a go-between for you and the hotel.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <CreditCard className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  3. Pricing and Payments
                </h2>
                <p className="text-gray-600">Prices include required taxes and are shown in EGP. At the time of the reservation, full payment is required. We do not keep your financial information; instead, we use secured third-party processors.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <XCircle className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  4. Cancellations
                </h2>
                <p className="text-gray-600">Each hotel has different cancellation policies. Before making a reservation, please check the hotel&apos;s policies. If required, refunds will be handled according to this policy.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <RefreshCw className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  5. Refunds
                </h2>
                <p className="text-gray-600">After confirmation, refunds are made in between five and ten business days. Refund problems between you and the hotel are not Hotlio&apos;s responsibility.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Users className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  6. User Accounts
                </h2>
                <p className="text-gray-600">It is your responsibility to keep your account private. Report any prohibited activity right away. To register, you must be at least eighteen.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Shield className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  7. Privacy Policy
                </h2>
                <p className="text-gray-600">We manage your personal information consistent with our privacy policy.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <AlertTriangle className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  8. Prohibited Activities
                </h2>
                <p className="text-gray-600">You are prohibited from harassing people, use the website illegally, or mess with its functionality. If an account violates this, we reserve the right to suspend it.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <FileText className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  9. Intellectual Property
                </h2>
                <p className="text-gray-600">Every piece of content on Hotlio, including text and logos, belongs to us or our licensees. It cannot be duplicated or shared without a written consent.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Globe className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  10. Third-Party Links
                </h2>
                <p className="text-gray-600">Links to other websites may be found on our website. Their procedures and content are not our responsibility. Use them at your own cost.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Scale className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  11. Limitation of Liability
                </h2>
                <p className="text-gray-600">Hotlio will not be responsible for any consequential or indirect losses resulting from your use of our services, to the extent that the law permits.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Briefcase className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  12. Hotel Responsibilities
                </h2>
                <p className="text-gray-600">The availability of rooms and services is the exclusive responsibility of hotels. Problems like cancellations, poor service, or hotel cancellations are not Hotlio&apos;s duty.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Lock className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  13. Travel Documentation
                </h2>
                <p className="text-gray-600">It is your responsibility to have appropriate passports, visas, and any other travel documents needed for your visit. Verify criteria prior to making a reservation.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Heart className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  14. Special Requests
                </h2>
                <p className="text-gray-600">The hotel should be informed of any special requests (such as dietary restrictions or preference rooms). Although they are not required to, hotels can offer accommodations.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Clock className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  15. Force Majeure
                </h2>
                <p className="text-gray-600">Problems carried on by unpredictable events, such as natural disasters, war, or governmental acts, are not the responsibility of either party.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Star className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  16. Reviews and Ratings
                </h2>
                <p className="text-gray-600">Guest opinions appear in reviews. Inappropriate content may be removed. By publishing, you give us permission to use your review for marketing.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <ThumbsUp className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  17. Best Price Guarantee
                </h2>
                <p className="text-gray-600">Within 24 hours of booking your reservation, get in touch with us if you discover a better deal for the same hotel and dates. We&apos;ll either match it or refund the gap.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <DollarSign className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  18. Currency Conversion
                </h2>
                <p className="text-gray-600">Conversion fees are applicable if you pay in a currency other than the hotel&apos;s. Additional fees may be charged by your bank. We show estimates of conversions.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <RefreshCw className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  19. Changes to Terms
                </h2>
                <p className="text-gray-600">These terms may be updated. Modifications take effect right away after they are posted. Approval is shown by your regular use. Visit this website from time to time.</p>
              </div>
            </div>
          </section>
          <section className="p-5 border border-gray-200 rounded-lg group hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3">
              <Mail className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-yellow-500 transition-colors duration-300">
                  20. Contact Us
                </h2>
                <p className="text-gray-600">
                  For complaints regarding these terms, get in touch with us at{" "}
                  <a href="mailto:support@hotlio.com" className="text-yellow-600 hover:underline">
                    support@hotlio.com
                  </a>
                </p>
              </div>
            </div>
          </section>
        </div>
        <div className="mt-8 text-sm text-gray-500 border-t border-gray-200 pt-6">
          <p>These Terms and Conditions were last updated on March 17, 2025. They are based on industry standards and adapted for Hotlio&apos;s services in Egypt.</p>
        </div>
      </div>
    </div>
  );
}
