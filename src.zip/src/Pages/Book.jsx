import React, { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";
import { apiFetch } from "../lib/api";
import { useAuth } from "../Context/AuthContext";

export default function Book() {
  const location = useLocation();
  const navigate = useNavigate();
  const hotel = location.state?.hotel || location.state;
  const rooms = useMemo(() => [
    { type: "Single Room", price: hotel?.price || 0, max: 1 },
    { type: "Double Room", price: (hotel?.price || 0) + 300, max: 2 },
    { type: "Suite", price: (hotel?.price || 0) + 800, max: 4 },
  ], [hotel?.price]);
  const [nights, setNights] = useState(1);
  const [selectedRoom, setSelectedRoom] = useState(rooms[0]);
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [bookingMessage, setBookingMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const totalGuests = adults + children;
  const isOverCapacity = totalGuests > selectedRoom.max;
  const totalPrice = nights * (selectedRoom?.price || 0);

  if (!hotel) {
    return <div className="p-10 text-center text-red-500">No hotel data found. Please go back and select a hotel.</div>;
  }

  const { user } = useAuth();

  async function handleBooking() {
    setIsSubmitting(true);
    setBookingMessage("");

    try {
      await apiFetch("/api/bookings", {
        method: "POST",
        body: JSON.stringify({
          hotelId: hotel._id,
          dates: `${new Date().toISOString().split("T")[0]} for ${nights} night(s)`,
          nights,
          price: totalPrice,
          roomType: selectedRoom.type,
          adults,
          children,
          status: "pending",
        }),
      });
      setBookingMessage("Booking recorded successfully!");

      const overlay = document.createElement('div');
      overlay.id = 'booking-success-popup';
      overlay.className = 'fixed inset-0 bg-gray-900/30 z-[9999] flex items-center justify-center p-4 transition-all duration-300 ease-out backdrop-blur-sm';
      overlay.style.animation = 'fadeInOverlay 0.3s ease-out';
      overlay.innerHTML = `
        <div class="bg-white/95 backdrop-blur-md rounded-3xl p-12 max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/50 transform scale-95 animate-popIn scale-in-center duration-400 ease-out">
          <div class="text-center mb-6">
            <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg class="w-12 h-12 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </div>
            <h2 class="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
            <p class="text-gray-600 mb-6">Your booking at <strong>${hotel.name}</strong> has been recorded successfully.</p>
            <p class="text-lg font-semibold text-yellow-600">${totalPrice} L.E total</p>
          </div>
          <div class="flex gap-3 pt-4">
            <button onclick="document.getElementById('booking-success-popup').remove(); window.location.href='/Profile';" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-xl font-medium transition-all duration-200">
              Go to Profile
            </button>
            <button onclick="document.getElementById('booking-success-popup').remove()" class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 px-6 rounded-xl font-medium transition-all duration-200">
              Close
            </button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);

    } catch (error) {
      setBookingMessage(error.message);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="w-full min-h-screen bg-slate-100">
      <Swiper
        modules={[Autoplay]}
        spaceBetween={10}
        slidesPerView={1}
        loop={true}
        autoplay={{ delay: 3000 }}
        className="w-full h-[400px]"
      >
        {hotel.images?.map((img, index) => (
          <SwiperSlide key={index}>
            <img
              src={img}
              className="w-full h-[400px] object-cover"
              alt={`Hotel View ${index + 1}`}
            />
          </SwiperSlide>
        ))}
      </Swiper>

      <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-extrabold text-center mb-8 text-black drop-shadow-2xl tracking-tight transform transition-all duration-700 hover:scale-105">
          Book Your <span className="inline-block transition-transform duration-700 hover:rotate-3 hover:scale-110">Stay</span>
        </h1>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-semibold">{hotel.name}</h2>
          <p className="text-gray-500 mt-1">{hotel.location}</p>
          <p className="mt-2 font-bold text-yellow-600">{hotel.price} L.E/Day</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div className="bg-white p-4 rounded-xl shadow">
            <h3 className="text-lg font-semibold mb-2">Nights</h3>
            <div className="flex items-center gap-4">
              <button onClick={() => setNights((n) => Math.max(1, n - 1))} className="bg-black text-white font-sans px-4 py-2 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">-</button>
              <span className="text-xl font-bold">{nights}</span>
              <button onClick={() => setNights((n) => n + 1)} className="bg-black text-white font-sans px-4 py-2 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">+</button>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow">
            <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
              <img src="https://img.icons8.com/?size=100&id=hI8Z5yfrLcE0&format=png&color=000000" alt="bed" className="w-6 h-6" />
              Room Type
            </h3>
            <select
              className="w-full p-2 border rounded-lg"
              value={selectedRoom.type}
              onChange={(e) => {
                const room = rooms.find((r) => r.type === e.target.value);
                setSelectedRoom(room);
              }}
            >
              {rooms.map((room, index) => (
                <option key={index} value={room.type}>
                  {room.type} - {room.price} L.E/Day (Max: {room.max})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-6 bg-white p-6 rounded-xl shadow">
          <h3 className="text-lg font-semibold mb-4">Guests</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between max-w-xs">
              <span>Adults</span>
              <div className="flex items-center gap-4">
                <button onClick={() => setAdults((a) => Math.max(1, a - 1))} className="bg-black text-white font-sans px-3 py-1 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">-</button>
                <span className="w-4 text-center">{adults}</span>
                <button onClick={() => setAdults((a) => a + 1)} className="bg-black text-white font-sans px-3 py-1 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">+</button>
              </div>
            </div>
            <div className="flex items-center justify-between max-w-xs">
              <span>Children</span>
              <div className="flex items-center gap-4">
                <button onClick={() => setChildren((c) => Math.max(0, c - 1))} className="bg-black text-white font-sans px-3 py-1 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">-</button>
                <span className="w-4 text-center">{children}</span>
                <button onClick={() => setChildren((c) => c + 1)} className="bg-black text-white font-sans px-3 py-1 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white">+</button>
              </div>
            </div>
          </div>
          {isOverCapacity && (
            <div className="mt-4 flex items-center gap-3 bg-red-50 border border-red-300 text-red-700 px-4 py-3 rounded-xl animate-pulse">
              <span>!</span>
              <div>
                <p className="font-semibold">Capacity Exceeded!</p>
                <p className="text-sm">Max allowed: {selectedRoom.max} persons for a {selectedRoom.type}.</p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 bg-white p-6 rounded-xl shadow flex justify-between items-center">
          <div>
            <h3 className="text-gray-500 uppercase text-xs font-bold tracking-wider">Total Price</h3>
            <p className="text-3xl font-bold text-yellow-600">{totalPrice} L.E/Day</p>
          </div>
          <div className="text-right">
            {bookingMessage && <p className="mb-2 text-sm text-blue-600">{bookingMessage}</p>}
            <button
              disabled={isOverCapacity || isSubmitting}
              onClick={handleBooking}
              className={`px-8 py-3 font-semibold text-white transition-all ${isOverCapacity || isSubmitting ? "bg-gray-400 cursor-not-allowed rounded-lg" : "bg-black font-sans rounded-md duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white"}`}
            >
              {isSubmitting ? "Recording..." : "Proceed to Payment"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
