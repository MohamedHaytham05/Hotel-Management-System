import { useState } from "react";
import { Link } from "react-router-dom";
import { Hotel, BookOpen, Calendar, Users, Trophy, Star, Globe, BedDouble, ChefHat, Dumbbell, Flower2, Car, Wifi, ChevronRight, ChevronUp, Sparkles, Utensils, Waves } from 'lucide-react';
function About() {
  const [showMore, setShowMore] = useState(false);
  return (
    <div className="max-w-4xl mx-auto p-10">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-900 mb-4">About Our Hotel</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">Experience luxury, comfort, and exceptional service in the heart of the city</p>
      </div>
      <div className="bg-linear-to-r from-blue-600 to-indigo-600 text-white p-12 rounded-3xl mb-12 text-center shadow-xl">
        <Hotel className="w-20 h-20 mx-auto mb-4" />
        <h2 className="text-3xl font-bold mb-4">Luxury Redefined</h2>
        <p className="text-lg max-w-2xl mx-auto opacity-90">Since 2010, we've been providing unforgettable experiences for travelers from around the world</p>
      </div>
      <div className="grid md:grid-cols-2 gap-10 mb-12">
        <div className="bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2"><BookOpen className="w-8 h-8 text-blue-600" />Our Story</h2>
          <p className="text-gray-600 leading-relaxed mb-4">Founded in 2010, our hotel started with a simple mission: to provide travelers with a home away from home. What began as a small family-owned business has grown into one of the most beloved hotels in the region.</p>
          {showMore && <p className="text-gray-600 leading-relaxed">Over the years, we've welcomed guests from over 50 countries, earned numerous awards for excellence, and built a team of dedicated professionals who share our passion for hospitality. We've recently completed a full renovation to ensure our facilities meet the highest modern standards while preserving the charm that our guests love.</p>}
          <button onClick={() => setShowMore(!showMore)} className="mt-4 text-blue-600 font-medium hover:text-blue-800 transition flex items-center gap-1">{showMore ? (<>Show less <ChevronUp className="w-4 h-4" /></>) : (<>Read more <ChevronRight className="w-4 h-4" /></>)}</button>
        </div>
        <div className="bg-linear-to-br from-blue-50 to-indigo-50 p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2"><Calendar className="w-8 h-8 text-blue-600" />Quick Facts</h2>
          <div className="space-y-4">
            {[
              { icon: Calendar, label: 'Years of Service', value: '15+ Years' },
              { icon: Users, label: 'Happy Guests', value: '50,000+' },
              { icon: Trophy, label: 'Awards Won', value: '12 Awards' },
              { icon: Star, label: 'Average Rating', value: '4.8/5' },
              { icon: Globe, label: 'Nationalities Served', value: '50+' },
              { icon: BedDouble, label: 'Rooms', value: '120 Rooms' }
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (<div key={index} className="flex items-center justify-between border-b border-gray-200 pb-2"><span className="text-gray-600 flex items-center gap-2"><Icon className="w-4 h-4 text-blue-500" />{stat.label}</span><span className="font-bold text-gray-800">{stat.value}</span></div>);
            })}
          </div>
        </div>
      </div>
      <div className="mb-12">
        <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">Our Premium Facilities</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: Waves, name: 'Swimming Pool', desc: 'Outdoor heated pool open year-round' },
            { icon: Utensils, name: 'Restaurant', desc: 'Fine dining with international cuisine' },
            { icon: Dumbbell, name: 'Fitness Center', desc: '24/7 gym with modern equipment' },
            { icon: Flower2, name: 'Spa', desc: 'Relaxing massages and treatments' },
            { icon: Car, name: 'Free Parking', desc: 'Secure parking for all guests' },
            { icon: Wifi, name: 'High-Speed WiFi', desc: 'Free WiFi throughout the hotel' }
          ].map((facility, index) => {
            const Icon = facility.icon;
            return (<div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition"><Icon className="w-12 h-12 text-blue-600 mb-3" /><h3 className="text-xl font-semibold mb-2">{facility.name}</h3><p className="text-gray-600">{facility.desc}</p></div>);
          })}
        </div>
      </div>
      <div className="bg-gray-50 p-8 rounded-xl mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">What Our Guests Say</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {[
            { name: "John Smith", text: "Best hotel experience ever! The staff went above and beyond to make our stay special.", rating: 5 },
            { name: "Sarah Johnson", text: "Beautiful rooms, amazing location, and the breakfast was incredible!", rating: 5 }
          ].map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">{testimonial.name.charAt(0)}</div>
                <div><p className="font-semibold">{testimonial.name}</p><div className="flex text-yellow-400">{[...Array(5)].map((_, i) => (<Star key={i} className={`w-4 h-4 ${i < testimonial.rating ? 'fill-current' : 'stroke-current opacity-30'}`} />))}</div></div>
              </div>
              <p className="text-gray-600 italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-blue-600 text-white p-8 rounded-xl text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Experience Our Hospitality?</h2>
        <p className="mb-6">Book your stay now and enjoy a memorable vacation</p>
        <Link to="/Hotels" className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition mx-auto inline-block">Book Your Stay</Link>
      </div>
    </div>
  );
}
export default About;
