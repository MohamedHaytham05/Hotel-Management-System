import React, { useState } from 'react';
import { Bell, Trash2 } from 'lucide-react';
import { useNotifications } from "../Context/NotificationContext";

export default function NotificationHistoryPage() {
  const { notifications, isLoading, markingAllRead, unreadCount, markAllAsRead, deleteNotification } = useNotifications();
  const [sortBy, setSortBy] = useState('dateNewest');

  const sortList = (list) => {
    switch (sortBy) {
      case 'dateNewest':
        return [...list].sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date));
      case 'dateOldest':
        return [...list].sort((a, b) => new Date(a.createdAt || a.date) - new Date(b.createdAt || b.date));
      case 'az':
        return [...list].sort((a, b) => a.message.localeCompare(b.message));
      case 'za':
        return [...list].sort((a, b) => b.message.localeCompare(a.message));
      default:
        return list;
    }
  };

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - 7);
  const recent = sortList(notifications).filter((notification) => new Date(notification.createdAt || notification.date) >= cutoffDate);
  const older = sortList(notifications).filter((notification) => new Date(notification.createdAt || notification.date) < cutoffDate);

  const renderNotification = (notification) => (
    <div
      key={notification._id}
      className={`p-4 rounded-lg border ${
        notification.read ? 'bg-gray-50 border-gray-200' : 'bg-yellow-50 border-yellow-200'
      }`}
    >
      <div className="flex justify-between items-start">
        <p className={`text-gray-800 ${!notification.read && 'font-semibold'}`}>
          {notification.message}
        </p>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">{new Date(notification.createdAt || notification.date).toLocaleDateString()}</span>
          <button
            onClick={() => deleteNotification(notification._id)}
            className="text-gray-400 hover:text-red-500 transition"
            aria-label="Delete notification"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>
      {!notification.read && (
        <span className="inline-block mt-2 text-xs bg-yellow-500 text-white px-2 py-1 rounded-full">
          New
        </span>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <Bell className="text-yellow-500" size={32} />
            <h1 className="text-3xl font-bold text-gray-800">Notification History</h1>
          </div>
          <div className="flex gap-3">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-yellow-500"
            >
              <option value="dateNewest">Newest First</option>
              <option value="dateOldest">Oldest First</option>
              <option value="az">A-Z</option>
              <option value="za">Z-A</option>
            </select>
            <button
              onClick={markAllAsRead}
              disabled={markingAllRead || unreadCount === 0}
              className={`px-4 py-2 rounded-md text-white transition ${
                markingAllRead || unreadCount === 0
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-yellow-500 hover:bg-yellow-600'
              }`}
            >
              {markingAllRead ? 'Marking...' : `Mark All as Read (${unreadCount})`}
            </button>
          </div>
        </div>
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4"></div>
            <p>Loading notifications...</p>
          </div>
        ) : notifications.length === 0 ? (
          <p className="text-gray-500 text-center py-12">
            No notifications yet. <button onClick={() => window.location.reload()} className="text-yellow-600 hover:underline">Refresh</button>
          </p>
        ) : (
          <div className="space-y-4">
            {recent.length > 0 && (
              <>
                <h2 className="text-lg font-semibold text-gray-700">Recent</h2>
                {recent.map(renderNotification)}
              </>
            )}
            {older.length > 0 && (
              <>
                {recent.length > 0 && <hr className="border-t-2 border-gray-300 my-6" />}
                <h2 className="text-lg font-semibold text-gray-700">Older</h2>
                {older.map(renderNotification)}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
