import React from 'react';
import HeroVideo from '../Components/HeroVideo';
import FeaturedHotels from '../Components/FeaturedHotels';
import WhyHotlio from '../Components/WhyHotlio';
import CallToAction from '../Components/CallToAction';
import Hero from '../Components/Hero1';
export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <HeroVideo />
      <FeaturedHotels />
      <section className="py-16 bg-gray-50">
        <div className="flex flex-col md:flex-row">
          <WhyHotlio />
          <div className="w-full md:w-1/2">
            <Hero />
          </div>
        </div>
      </section>
      <CallToAction />
    </div>
  );
}
