import React, { useState } from 'react';
import { Link, useNavigate } from "react-router-dom";
import InputFieldLogin from '../Components/InputFieldLogin';
import PasswordFieldLogin from '../Components/PasswordFieldLogin';
import CheckboxFieldLogin from '../Components/CheckboxFieldLogin';
import { apiFetch } from '../lib/api';
import { useAuth } from '../Context/AuthContext';

function SubmitButton({ isLoading }) {
  return (
    <button
      type="submit"
      disabled={isLoading}
      className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isLoading ? 'LOGGING IN...' : 'LOGIN'}
    </button>
  );
}

const Login = () => {
  const { refreshAuth } = useAuth();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const { email, password } = formData;

    if (!email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) newErrors.email = 'Please enter a valid email address';

    if (!password) newErrors.password = 'Password is required';
    else if (password.length < 6 || password.length > 10) newErrors.password = 'Password must be 6-10 characters long';
    else if (!/[A-Z]/.test(password)) newErrors.password = 'Must contain at least one uppercase letter';
    else if (!/[a-z]/.test(password)) newErrors.password = 'Must contain at least one lowercase letter';
    else if (!/\d/.test(password)) newErrors.password = 'Must contain at least one number';
    else if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) newErrors.password = 'Must contain at least one special character';

    if (!agreeTerms) newErrors.terms = 'You must agree to the terms and conditions';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const response = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(formData),
      });
      localStorage.setItem('token', response.token);
      await refreshAuth();
      navigate('/Profile');
    } catch (error) {
      setErrors((prev) => ({ ...prev, form: error.message }));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-lg w-full">
        <div className="bg-white p-10 rounded-xl shadow-lg border border-gray-200">
          <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">Login</h1>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <InputFieldLogin
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
              placeholder="Enter your email"
            />
            <PasswordFieldLogin
              name="password"
              value={formData.password}
              onChange={handleChange}
              error={errors.password}
              placeholder="Enter your password"
            />
            <CheckboxFieldLogin
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              error={errors.terms}
            />
            {errors.form && <p className="text-sm text-red-600">{errors.form}</p>}
            <SubmitButton isLoading={isLoading} />
          </form>
        </div>
        <div className="mt-6 text-center">
          <Link to="/Signup" className="text-sm text-blue-600 hover:underline">
            Don't have an account? Create one here
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
