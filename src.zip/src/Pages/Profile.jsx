import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, MapPin, Phone, Calendar, LogOut, Award, Heart, Edit2, CheckCircle, XCircle, Trash2, Save, Star } from 'lucide-react';
import ProfileAvatar from '../Components/ProfileAvatar';
import ProfileStatCard from '../Components/ProfileStatCard';
import BookingCard from '../Components/BookingCard';
import ProfileReviewCard from '../Components/ProfileReviewCard';
import FavoriteHotelCard from '../Components/FavoriteHotelCard';
import ProfileTabs from '../Components/ProfileTabs';
import { apiFetch } from '../lib/api';
import { useAuth } from '../Context/AuthContext';

export default function Profile() {
  const { user: authUser, isLoading, isAdmin } = useAuth();
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    city: '',
    phone: '',
    memberSince: '',
    image: null
  });

  const [activeTab, setActiveTab] = useState('bookings');
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [editErrors, setEditErrors] = useState({});
  const [bookings, setBookings] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [editingReviewId, setEditingReviewId] = useState(null);
  const [editReviewData, setEditReviewData] = useState({ rating: 5, text: '' });

  useEffect(() => {
    if (!authUser) return;

    const normalizedUser = {
      name: authUser.name || 'User',
      email: authUser.email || 'user@example.com',
      city: authUser.city || 'Cairo',
      phone: authUser.phone || '+20123456789',
      memberSince: authUser.createdAt ? new Date(authUser.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : 'Jan 2026',
      image: null
    };

    setUserData(normalizedUser);
    setEditedData(normalizedUser);
  }, [authUser]);

  useEffect(() => {
    if (!authUser) return;

    async function loadData() {
      try {
        const [bookingsRes, reviewsData, favoritesRes] = await Promise.all([
          apiFetch('/api/bookings'),
          apiFetch(isAdmin ? '/api/reviews?admin=true' : '/api/reviews?mine=true'),
          apiFetch(isAdmin ? '/api/favorites?admin=true' : '/api/favorites'),
        ]);

        setBookings((bookingsRes.bookings || []).map((booking) => ({
          id: booking._id,
          hotelName: booking.hotelId?.name || 'Hotel',
          location: booking.hotelId?.location || '',
          dates: booking.dates,
          nights: booking.nights,
          price: booking.price,
          status: booking.status,
          userName: booking.userId?.name || 'User',
          userEmail: booking.userId?.email || '',
        })));

        setReviews((reviewsData || []).map((review) => ({
          id: review._id,
          hotelName: review.hotelId?.name || 'Hotel',
          rating: review.rating,
          text: review.text,
          date: new Date(review.createdAt).toLocaleDateString(),
          userName: review.userId?.name || 'User',
        })));

        setFavorites((favoritesRes.favorites || []).map((fav) => ({
          id: fav._id,
          hotelId: fav.hotelId?._id,
          name: fav.hotelId?.name || 'Hotel',
          location: fav.hotelId?.location,
          rating: fav.hotelId?.rating,
          price: fav.hotelId?.price,
          image: fav.hotelId?.images?.[0],
          userName: fav.userId?.name || 'User',
        })));
      } catch (error) {
        console.error('Load data error:', error);
        setBookings([]);
        setReviews([]);
        setFavorites([]);
      }
    }

    loadData();
  }, [authUser, isAdmin]);

  const stats = [
    { icon: Calendar, label: isAdmin ? 'Total Bookings' : 'Total Bookings', value: bookings.length, color: 'bg-blue-500' },
    { icon: Award, label: isAdmin ? 'Total Reviews' : 'Reviews Written', value: reviews.length, color: 'bg-yellow-500' },
    { icon: Heart, label: isAdmin ? 'Total Favorites' : 'Favorite Hotels', value: favorites.length, color: 'bg-red-500' },
    { icon: Award, label: 'Loyalty Points', value: '1,250', color: 'bg-purple-500' },
  ];

  const handleApproveBooking = async (bookingId) => {
    try {
      await apiFetch(`/api/bookings/${bookingId}`, {
        method: 'PUT',
        body: JSON.stringify({ status: 'completed' }),
      });
      setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: 'completed' } : b));
    } catch (error) {
      console.error('Approve booking error:', error);
      alert('Failed to approve booking');
    }
  };

  const handleRejectBooking = async (bookingId) => {
    try {
      await apiFetch(`/api/bookings/${bookingId}`, {
        method: 'PUT',
        body: JSON.stringify({ status: 'cancelled' }),
      });
      setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: 'cancelled' } : b));
    } catch (error) {
      console.error('Reject booking error:', error);
      alert('Failed to reject booking');
    }
  };

  const handleDeleteReview = async (reviewId) => {
    if (!window.confirm('Are you sure you want to delete this review?')) return;
    try {
      await apiFetch(`/api/reviews/${reviewId}`, { method: 'DELETE' });
      setReviews(prev => prev.filter(r => r.id !== reviewId));
    } catch (error) {
      console.error('Delete review error:', error);
      alert('Failed to delete review');
    }
  };

  const handleEditReview = (review) => {
    setEditingReviewId(review.id);
    setEditReviewData({ rating: review.rating, text: review.text });
  };

  const handleSaveReview = async (reviewId) => {
    try {
      await apiFetch(`/api/reviews/${reviewId}`, {
        method: 'PUT',
        body: JSON.stringify(editReviewData),
      });
      setReviews(prev => prev.map(r => r.id === reviewId ? { ...r, rating: editReviewData.rating, text: editReviewData.text } : r));
      setEditingReviewId(null);
    } catch (error) {
      console.error('Update review error:', error);
      alert('Failed to update review');
    }
  };

  const handleDeleteFavorite = async (favoriteId) => {
    if (!window.confirm('Are you sure you want to delete this favorite?')) return;
    try {
      await apiFetch(`/api/favorites/${favoriteId}`, { method: 'DELETE' });
      setFavorites(prev => prev.filter(f => f.id !== favoriteId));
    } catch (error) {
      console.error('Delete favorite error:', error);
      alert('Failed to delete favorite');
    }
  };

  const fileInputRef = useRef(null);

  const handleImageChange = () => {
    fileInputRef.current?.click();
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file.');
      return;
    }

    if (userData.image) {
      const confirmReplace = window.confirm('You already have a profile image. Do you want to replace it?');
      if (!confirmReplace) {
        e.target.value = '';
        return;
      }
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const imageUrl = event.target.result;
      setUserData(prev => ({ ...prev, image: imageUrl }));
      if (isEditing) {
        setEditedData(prev => ({ ...prev, image: imageUrl }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleImageRemove = () => {
    const confirmRemove = window.confirm('Are you sure you want to remove your profile image?');
    if (confirmRemove) {
      setUserData(prev => ({ ...prev, image: null }));
      if (isEditing) {
        setEditedData(prev => ({ ...prev, image: null }));
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhone = (phone) => {
    return /^[\d\s\-+()]{7,}$/.test(phone);
  };

  const handleEditToggle = async () => {
    if (isEditing) {
      const errors = {};
      if (!validateEmail(editedData.email)) {
        errors.email = 'Invalid email address';
      }
      if (!validatePhone(editedData.phone)) {
        errors.phone = 'Invalid phone number';
      }
      if (Object.keys(errors).length > 0) {
        setEditErrors(errors);
        return;
      }

      try {
        const updatedUser = await apiFetch('/api/auth/me', {
          method: 'PUT',
          body: JSON.stringify({
            name: editedData.name,
            email: editedData.email,
            city: editedData.city,
            phone: editedData.phone,
          }),
        });
        const normalizedUser = {
          ...userData,
          name: updatedUser.name,
          email: updatedUser.email,
          city: updatedUser.city || '',
          phone: updatedUser.phone || '',
          image: editedData.image,
        };
        setUserData(normalizedUser);
        setEditedData(normalizedUser);
        setEditErrors({});
        setIsEditing(false);
      } catch (error) {
        setEditErrors({ form: error.message });
      }
    } else {
      setEditedData({ ...userData });
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedData({ ...userData });
    setEditErrors({});
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedData(prev => ({ ...prev, [name]: value }));
    if (editErrors[name]) {
      setEditErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleRemoveFavorite = (hotelId) => {
    setFavorites(prev => prev.filter(h => h.hotelId !== hotelId));
  };

  const renderTabContent = () => {
    switch(activeTab) {
      case 'bookings':
        return (
          <div className="space-y-3">
            {bookings.map(booking => (
              <div key={booking.id}>
                <BookingCard booking={booking} />
                {isAdmin && (
                  <div className="flex gap-2 mt-1 ml-2">
                    <span className="text-xs text-gray-500">User: {booking.userName} ({booking.userEmail})</span>
                    {booking.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleApproveBooking(booking.id)}
                          className="flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded text-xs hover:bg-green-200 transition"
                        >
                          <CheckCircle className="w-3 h-3" /> Approve
                        </button>
                        <button
                          onClick={() => handleRejectBooking(booking.id)}
                          className="flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded text-xs hover:bg-red-200 transition"
                        >
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      </>
                    )}
                    {booking.status === 'completed' && (
                      <span className="text-xs text-green-600 font-medium">Approved</span>
                    )}
                    {booking.status === 'cancelled' && (
                      <span className="text-xs text-red-600 font-medium">Rejected</span>
                    )}
                  </div>
                )}
              </div>
            ))}
            {bookings.length === 0 && (
              <p className="text-gray-500 text-center py-8">No bookings found.</p>
            )}
          </div>
        );

      case 'reviews':
        return (
          <div className="space-y-3">
            {reviews.map(review => (
              <div key={review.id}>
                {editingReviewId === review.id ? (
                  <div className="bg-white p-4 rounded-lg border border-gray-200">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-medium">Rating:</span>
                      {[1,2,3,4,5].map(star => (
                        <button
                          key={star}
                          onClick={() => setEditReviewData(prev => ({ ...prev, rating: star }))}
                        >
                          <Star className={`w-5 h-5 ${star <= editReviewData.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                        </button>
                      ))}
                    </div>
                    <textarea
                      value={editReviewData.text}
                      onChange={(e) => setEditReviewData(prev => ({ ...prev, text: e.target.value }))}
                      className="w-full p-2 border rounded-lg mb-2 text-sm"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleSaveReview(review.id)}
                        className="flex items-center gap-1 px-3 py-1 bg-blue-600 text-white rounded text-xs hover:bg-blue-700 transition"
                      >
                        <Save className="w-3 h-3" /> Save
                      </button>
                      <button
                        onClick={() => setEditingReviewId(null)}
                        className="px-3 py-1 bg-gray-200 text-gray-700 rounded text-xs hover:bg-gray-300 transition"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <ProfileReviewCard review={review} />
                )}
                {isAdmin && editingReviewId !== review.id && (
                  <div className="flex gap-2 mt-1 ml-2">
                    <span className="text-xs text-gray-500">User: {review.userName}</span>
                    <button
                      onClick={() => handleEditReview(review)}
                      className="flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs hover:bg-blue-200 transition"
                    >
                      <Edit2 className="w-3 h-3" /> Edit
                    </button>
                    <button
                      onClick={() => handleDeleteReview(review.id)}
                      className="flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded text-xs hover:bg-red-200 transition"
                    >
                      <Trash2 className="w-3 h-3" /> Delete
                    </button>
                  </div>
                )}
              </div>
            ))}
            {reviews.length === 0 && (
              <p className="text-gray-500 text-center py-8">No reviews found.</p>
            )}
          </div>
        );

      case 'favorites':
        return (
          <div className="space-y-3">
            {favorites.map(hotel => (
              <div key={hotel.id}>
                <FavoriteHotelCard hotel={hotel} onRemove={isAdmin ? undefined : handleRemoveFavorite} />
                {isAdmin && (
                  <div className="flex gap-2 mt-1 ml-2">
                    <span className="text-xs text-gray-500">User: {hotel.userName}</span>
                    <button
                      onClick={() => handleDeleteFavorite(hotel.id)}
                      className="flex items-center gap-1 px-2 py-1 bg-red-100 text-red-700 rounded text-xs hover:bg-red-200 transition"
                    >
                      <Trash2 className="w-3 h-3" /> Delete
                    </button>
                  </div>
                )}
              </div>
            ))}
            {favorites.length === 0 && (
              <p className="text-gray-500 text-center py-8">No favorites found.</p>
            )}
          </div>
        );

      case 'settings':
        return (
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Edit Profile</h3>
              {!isEditing && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                  title="Edit profile"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              )}
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  name="name"
                  value={isEditing ? editedData.name : userData.name}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isEditing ? 'bg-white border-gray-300' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  name="email"
                  value={isEditing ? editedData.email : userData.email}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isEditing ? 'bg-white border-gray-300' : 'bg-gray-50 border-gray-200'
                  } ${editErrors.email ? 'border-red-500' : ''}`}
                />
                {editErrors.email && (
                  <p className="mt-1 text-sm text-red-600">{editErrors.email}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                <input
                  type="text"
                  name="city"
                  value={isEditing ? editedData.city : userData.city}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isEditing ? 'bg-white border-gray-300' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  name="phone"
                  value={isEditing ? editedData.phone : userData.phone}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isEditing ? 'bg-white border-gray-300' : 'bg-gray-50 border-gray-200'
                  } ${editErrors.phone ? 'border-red-500' : ''}`}
                />
                {editErrors.phone && (
                  <p className="mt-1 text-sm text-red-600">{editErrors.phone}</p>
                )}
              </div>

              {editErrors.form && (
                <p className="mt-1 text-sm text-red-600">{editErrors.form}</p>
              )}

              {isEditing && (
                <div className="flex gap-3">
                  <button
                    onClick={handleEditToggle}
                    className="flex-1 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
                  >
                    Save Changes
                  </button>
                  <button
                    onClick={handleCancelEdit}
                    className="flex-1 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition font-medium"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          className="hidden"
        />

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <ProfileAvatar
              name={userData.name}
              image={userData.image}
              onImageChange={handleImageChange}
              onImageRemove={handleImageRemove}
            />

            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-800 mb-2">{userData.name}</h1>
              {isAdmin && (
                <span className="inline-block mb-2 px-2 py-1 bg-purple-100 text-purple-700 text-xs font-semibold rounded-full">
                  Administrator
                </span>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail className="w-4 h-4" />
                  {userData.email}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="w-4 h-4" />
                  {userData.city}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Phone className="w-4 h-4" />
                  {userData.phone}
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  Member since {userData.memberSince}
                </div>
              </div>
            </div>

            <button
              onClick={async () => {
                try {
                  await apiFetch('/api/auth/logout', { method: 'POST' });
                  window.location.href = '/';
                } catch {
                  window.location.href = '/';
                }
              }}
              className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {stats.map((stat, index) => (
            <ProfileStatCard key={index} {...stat} />
          ))}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <ProfileTabs activeTab={activeTab} setActiveTab={setActiveTab} isAdmin={isAdmin} />
          <div className="p-6">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}
