import React, { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import SearchForm from "../Components/SearchForm";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { HotelSearchProvider, useHotelSearch } from "../Context/HotelSearchContext";
import { apiFetch } from "../lib/api";
import { Heart } from 'lucide-react';
import { useAuth } from "../Context/AuthContext";

function HotelsContent() {
  const navigate = useNavigate();
  const location = useLocation();
  const { selectedCity, setSelectedCity } = useHotelSearch();
  const [hotelsData, setHotelsData] = useState([]);
  const [userFavorites, setUserFavorites] = useState(new Set());
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    async function loadHotels() {
      try {
        const hotels = await apiFetch("/api/hotels");
        setHotelsData(hotels);
      } catch {
        setHotelsData([]);
      }
    }

    loadHotels();
  }, []);

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    async function loadFavorites() {
      try {
        const data = await apiFetch('/api/favorites');
        const favorites = new Set(data.favorites.map(f => f.hotelId._id));
        setUserFavorites(favorites);
      } catch {

      }
    }

    loadFavorites();
  }, [isAuthenticated, user]);

  const handleToggleFavorite = async (hotelId) => {
    if (!isAuthenticated) {
      alert('Please login to favorite hotels');
      return;
    }

    try {
      await apiFetch('/api/favorites/toggle', {
        method: 'POST',
        body: JSON.stringify({ hotelId })
      });

      setUserFavorites(prev => {
        const newSet = new Set(prev);
        if (newSet.has(hotelId)) {
          newSet.delete(hotelId);
        } else {
          newSet.add(hotelId);
        }
        return newSet;
      });
    } catch (error) {
      console.error('Toggle favorite failed:', error.message);
    }
  };

  const isFavorite = (hotelId) => userFavorites.has(hotelId);

  useEffect(() => {
    const queryLocation = new URLSearchParams(location.search).get("location");
    if (queryLocation) {
      setSelectedCity(queryLocation);
    }
  }, [location.search, setSelectedCity]);

  const filteredHotels = hotelsData.filter((hotel) => hotel.location === selectedCity || selectedCity === "");

  return (
    <div className="max-w-7xl mx-auto">
      <div className="relative h-[50vh] min-h-[400px] max-h-[700px] overflow-hidden rounded-b-2xl shadow-xl">
        <video
          autoPlay
          playsInline
          loop
          muted
          className="absolute top-0 left-0 w-full h-full object-cover"
          src="/Vid.mp4"
        />
        <div className="absolute inset-0 flex items-center justify-center p-4">
          <SearchForm />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        {filteredHotels.map((hotel) => (
          <div key={hotel._id} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <Swiper spaceBetween={10} slidesPerView={1} loop={true} autoplay={{ delay: 3000 }}>
              {hotel.images?.map((img, index) => (
                <SwiperSlide key={index}>
                  <img src={img} className="w-full h-64 object-cover" alt={hotel.name} />
                </SwiperSlide>
              ))}
            </Swiper>
            <div className="p-4 sm:p-6">
              <h2 className="text-lg sm:text-xl font-semibold text-slate-800">{hotel.name}</h2>
              <p className="text-sm sm:text-base text-gray-500">{hotel.location}</p>
              <p className="mt-2 text-sm sm:text-base font-bold text-yellow-600">{hotel.price} L.E/Day</p>
              <div className="flex items-center gap-1 mt-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className={`w-4 h-4 ${i < hotel.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}>
                    ★
                  </div>
                ))}
                <span className="ml-1 text-sm text-gray-600">({hotel.rating})</span>
              </div>
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => navigate("/Book", { state: hotel })}
                  className="flex-1 bg-black text-white font-sans py-2 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white"
                >
                  Book Now
                </button>
                <button
                  onClick={() => handleToggleFavorite(hotel._id)}
className={`p-2 rounded-md transition-all duration-300 hover:scale-110 w-12 active:scale-90 animate-pulse ${
                    isFavorite(hotel._id)
                      ? 'text-red-500 bg-red-50 hover:bg-red-100'
                      : 'text-gray-400 hover:text-red-500 hover:bg-gray-50'
                  }`}
                  title={isFavorite(hotel._id) ? 'Remove from favorites' : 'Add to favorites'}
                >
                  <Heart className={`w-5 h-5 ${isFavorite(hotel._id) ? 'fill-current' : ''}`} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Hotels() {
  return (
    <HotelSearchProvider>
      <HotelsContent />
    </HotelSearchProvider>
  );
}
