import TopBar from "../Components/TopBar";
import StatsCards from "../Components/StatsCards";
import RevenueChart from "../Components/RevenueChart";
import BookingChart from "../Components/BookingChart";
import RecentActivity from "../Components/RecentActivity";
import QuickStats from "../Components/QuickStats";
import { AdminDashboardProvider } from "../Context/AdminDashboardContext";

function Admin() {
  return (
    <AdminDashboardProvider>
      <div className="min-h-screen bg-gray-100">
        <TopBar />
        <div className="p-8">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Welcome back, Admin!</h2>
            <p className="text-gray-600 text-lg">Here's what's happening with your hotel today.</p>
          </div>
          <StatsCards />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <RevenueChart />
            <BookingChart />
          </div>
          <RecentActivity />
          <QuickStats />
        </div>
      </div>
    </AdminDashboardProvider>
  );
}

export default Admin;
