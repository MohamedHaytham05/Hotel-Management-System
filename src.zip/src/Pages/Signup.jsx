import React, { useState } from 'react';
import { Link, useNavigate } from "react-router-dom";
import InputFieldLogin from '../Components/InputFieldLogin';
import PasswordFieldLogin from '../Components/PasswordFieldLogin';
import CheckboxFieldLogin from '../Components/CheckboxFieldLogin';
import { apiFetch } from '../lib/api';
const SelectField = ({ label, name, value, onChange, error, options, placeholder }) => (<div><label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label><select id={name} name={name} value={value} onChange={onChange} required className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition bg-white ${error ? 'border-red-500' : 'border-gray-300'}`}><option value="" disabled>{placeholder}</option>{options.map(opt => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}</select>{error && <p className="mt-1 text-sm text-red-600">{error}</p>}</div>);
const SubmitButton = ({ isLoading }) => (<button type="submit" disabled={isLoading} className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition disabled:opacity-50 disabled:cursor-not-allowed">{isLoading ? 'SIGNING UP...' : 'SIGN UP'}</button>);
const Signup = () => {
  const [formData, setFormData] = useState({ name: '', email: '', city: '', phone: '', password: '' });
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const handleChange = (e) => { const { name, value } = e.target; setFormData(prev => ({ ...prev, [name]: value })); if (errors[name]) { setErrors(prev => ({ ...prev, [name]: '' })); } };
  const validateForm = () => {
    const newErrors = {};
    const { name, email, city, phone, password } = formData;
    if (!name) newErrors.name = 'Full name is required';
    if (!email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) newErrors.email = 'Please enter a valid email address';
    if (!city) newErrors.city = 'Please select your city';
    if (!phone) newErrors.phone = 'Phone number is required';
    else if (!/^[\d\s\-+()]{7,}$/.test(phone)) newErrors.phone = 'Enter a valid phone number';
if (!password) newErrors.password = 'Password is required';
    else if (password.length < 6 || password.length > 10) newErrors.password = 'Password must be 6-10 characters long';
    else if (!/[A-Z]/.test(password)) newErrors.password = 'Must contain at least one uppercase letter';
    else if (!/[a-z]/.test(password)) newErrors.password = 'Must contain at least one lowercase letter';
    else if (!/\d/.test(password)) newErrors.password = 'Must contain at least one number';
    else if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) newErrors.password = 'Must contain at least one special character';
    if (!agreeTerms) newErrors.terms = 'You must agree to the terms and conditions';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsLoading(true);
    try {
      await apiFetch('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(formData),
      });
      navigate('/Login');
    } catch (error) {
      setErrors((prev) => ({ ...prev, form: error.message }));
    } finally {
      setIsLoading(false);
    }
  };
  const cityOptions = [
    { value: 'Cairo', label: 'Cairo' }, { value: 'Alexandria', label: 'Alexandria' }, { value: 'Giza', label: 'Giza' }, { value: 'Luxor', label: 'Luxor' }, { value: 'Aswan', label: 'Aswan' }, { value: 'Sharm El Sheikh', label: 'Sharm El Sheikh' }, { value: 'Hurghada', label: 'Hurghada' }, { value: 'Marsa Alam', label: 'Marsa Alam' }, { value: 'Dahab', label: 'Dahab' }, { value: 'Nuweiba', label: 'Nuweiba' }, { value: 'Taba', label: 'Taba' }, { value: 'Safaga', label: 'Safaga' }, { value: 'El Gouna', label: 'El Gouna' }, { value: 'Port Said', label: 'Port Said' }, { value: 'Ismailia', label: 'Ismailia' }, { value: 'Suez', label: 'Suez' }, { value: 'Fayoum', label: 'Fayoum' }, { value: 'Minya', label: 'Minya' }, { value: 'Asyut', label: 'Asyut' }, { value: 'Sohag', label: 'Sohag' }, { value: 'Qena', label: 'Qena' }, { value: 'Matrouh', label: 'Matrouh' }, { value: 'Siwa', label: 'Siwa' }, { value: 'Ras Sedr', label: 'Ras Sedr' }, { value: 'Ain Sokhna', label: 'Ain Sokhna' }
  ];
  return (
    <div className="min-h-screen bg-white flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-lg w-full">
        <div className="bg-white p-10 rounded-xl shadow-lg border border-gray-200">
          <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">Create Account</h1>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <InputFieldLogin label="Full Name" name="name" type="text" value={formData.name} onChange={handleChange} error={errors.name} placeholder="Enter your full name" />
            <InputFieldLogin label="Email" name="email" type="email" value={formData.email} onChange={handleChange} error={errors.email} placeholder="Enter your email" />
            <SelectField label="City" name="city" value={formData.city} onChange={handleChange} error={errors.city} options={cityOptions} placeholder="Select your city" />
            <InputFieldLogin label="Phone Number" name="phone" type="tel" value={formData.phone} onChange={handleChange} error={errors.phone} placeholder="Enter your phone number" />
            <PasswordFieldLogin name="password" value={formData.password} onChange={handleChange} error={errors.password} placeholder="Create a password" />
            <CheckboxFieldLogin checked={agreeTerms} onChange={(e) => setAgreeTerms(e.target.checked)} error={errors.terms} />
            {errors.form && <p className="text-sm text-red-600">{errors.form}</p>}
            <SubmitButton isLoading={isLoading} />
          </form>
        </div>
        <div className="mt-6 text-center">
          <Link to="/Login" className="text-sm text-blue-600 hover:underline">Already have an account? Sign in</Link>
        </div>
      </div>
    </div>
  );
};
export default Signup;
