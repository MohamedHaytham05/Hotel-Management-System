const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  action: {
    type: String,
    enum: ['BOOKING_CREATED', 'BOOKING_CANCELLED', 'BOOKING_DELETED', 'REVIEW_POSTED', 'REVIEW_UPDATED', 'REVIEW_DELETED', 'FAVORITE_TOGGLED', 'FAVORITE_DELETED', 'LOGIN', 'LOGOUT', 'PROFILE_UPDATED', 'HOTEL_CREATED', 'HOTEL_UPDATED', 'HOTEL_DELETED', 'USER_REGISTERED'],
    required: true
  },
  details: {
    type: Object,
    default: {}
  },
  ipAddress: String
}, {
  timestamps: true
});

module.exports = mongoose.model('Activity', activitySchema);
