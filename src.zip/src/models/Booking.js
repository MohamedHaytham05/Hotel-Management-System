const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true },
  dates: { type: String, required: true },
  nights: { type: Number, required: true },
  price: { type: Number, required: true },
  roomType: { type: String, default: 'Single Room' },
  adults: { type: Number, default: 1 },
  children: { type: Number, default: 0 },
  status: { type: String, enum: ['completed', 'upcoming', 'cancelled', 'pending'], default: 'pending' }
}, { timestamps: true });

module.exports = mongoose.model('Booking', bookingSchema);
