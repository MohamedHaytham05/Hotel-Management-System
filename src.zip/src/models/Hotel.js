const mongoose = require('mongoose');

const hotelSchema = new mongoose.Schema({
  name: { type: String, required: true },
  location: { type: String },
  price: { type: Number },
  rating: { type: Number },
  images: [String],
  facilities: [String]
}, { timestamps: true });

module.exports = mongoose.model('Hotel', hotelSchema);
