import React from 'react';
const InputFieldLogin = ({ label, name, type, value, onChange, error, placeholder }) => {
  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input id={name} name={name} type={type} autoComplete={type === 'email' ? 'email' : 'off'} required value={value} onChange={onChange} className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition ${error ? 'border-red-500' : 'border-gray-300'}`} placeholder={placeholder} />
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    </div>
  );
};
export default InputFieldLogin;
