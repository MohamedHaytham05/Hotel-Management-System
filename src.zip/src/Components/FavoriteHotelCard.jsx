import React from 'react';
import { Star, Trash2 } from 'lucide-react';

const FavoriteHotelCard = ({ hotel, onRemove }) => (
  <div className="bg-white p-4 rounded-lg border border-gray-200 flex gap-3 relative group">
    <img src={hotel.image} alt={hotel.name} className="w-20 h-20 rounded-lg object-cover" />
    <div className="flex-1">
      <h3 className="font-semibold text-gray-800">{hotel.name}</h3>
      <p className="text-sm text-gray-500">{hotel.location}</p>
      <div className="flex items-center gap-2 mt-2">
        <div className="flex items-center gap-1">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium">{hotel.rating}</span>
        </div>
        <span className="text-sm text-gray-400">•</span>
        <span className="text-sm font-bold text-blue-600">{hotel.price} EGP/night</span>
      </div>
    </div>
    <button
      onClick={() => onRemove(hotel.id)}
      className="absolute top-2 right-2 p-1 bg-red-50 text-red-500 rounded-full opacity-0 group-hover:opacity-100 transition hover:bg-red-100"
      title="Remove from favorites"
    >
      <Trash2 className="w-4 h-4" />
    </button>
  </div>
);

export default FavoriteHotelCard;
