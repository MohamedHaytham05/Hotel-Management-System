import React from 'react';
import { BadgeCheck, Headphones, Lock, Star } from 'lucide-react';
export default function WhyHotlio() {
  return (
    <div className="w-full md:w-1/2 px-6 md:px-12 lg:px-16">
      <h2 className="text-3xl font-bold text-gray-800 mb-8">Why Hotlio</h2>
      <div className="space-y-6">
        <div className="flex items-start gap-4 p-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-[1.02] hover:bg-white/50">
          <BadgeCheck size={32} className="text-yellow-500 flex-shrink-0" />
          <div>
            <h3 className="text-xl font-semibold text-gray-800">Best Price Guarantee</h3>
            <p className="text-gray-600">With every booking, we make sure you receive the best prices.</p>
          </div>
        </div>
        <div className="flex items-start gap-4 p-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-[1.02] hover:bg-white/50">
          <Headphones size={32} className="text-yellow-500 flex-shrink-0" />
          <div>
            <h3 className="text-xl font-semibold text-gray-800">24/7 Customer Support</h3>
            <p className="text-gray-600">Our team is available to help you at any time and from any location.</p>
          </div>
        </div>
        <div className="flex items-start gap-4 p-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-[1.02] hover:bg-white/50">
          <Lock size={32} className="text-yellow-500 flex-shrink-0" />
          <div>
            <h3 className="text-xl font-semibold text-gray-800">Secure Booking</h3>
            <p className="text-gray-600">Your payment details are secure and protected at all times.</p>
          </div>
        </div>
        <div className="flex items-start gap-4 p-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-[1.02] hover:bg-white/50">
          <Star size={32} className="text-yellow-500 flex-shrink-0" />
          <div>
            <h3 className="text-xl font-semibold text-gray-800">Validated Reviews</h3>
            <p className="text-gray-600">To help you make choices, all reviews are submitted by actual guests.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
