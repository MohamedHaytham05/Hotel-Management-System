import React from 'react';
import { Calendar, MessageCircle, Heart, Settings } from 'lucide-react';

const ProfileTabs = ({ activeTab, setActiveTab, isAdmin }) => {
  const tabs = [
    { id: 'bookings', label: isAdmin ? 'Booking Log' : 'My Bookings', icon: Calendar },
    { id: 'reviews', label: isAdmin ? 'Review Log' : 'My Reviews', icon: MessageCircle },
    { id: 'favorites', label: isAdmin ? 'Favorite Log' : 'Favorites', icon: Heart },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="flex border-b border-gray-200">
      {tabs.map(tab => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-6 py-3 font-medium text-sm transition-colors relative ${
              activeTab === tab.id
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Icon className="w-4 h-4" />
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};

export default ProfileTabs;
