import React from 'react';

const ProfileStatCard = ({ icon, label, value, color }) => {
  const IconComponent = icon;

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
      <div className="flex items-center gap-3">
        <div className={`p-3 rounded-lg ${color}`}>
          <IconComponent className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-xl font-bold text-gray-800">{value}</p>
        </div>
      </div>
    </div>
  );
};

export default ProfileStatCard;
