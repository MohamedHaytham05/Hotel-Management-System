import React from 'react';
const CheckboxFieldLogin = ({ checked, onChange, error }) => {
  return (
    <div>
      <div className="flex items-center">
        <input
          id="terms"
          name="terms"
          type="checkbox"
          checked={checked}
          onChange={onChange}
          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
        />
        <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
          I agree to the <a href="/terms" className="text-blue-600 hover:underline">terms and conditions</a>
        </label>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  );
};
export default CheckboxFieldLogin;
