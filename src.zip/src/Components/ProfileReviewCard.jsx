import React from 'react';
import { Star } from 'lucide-react';

const ProfileReviewCard = ({ review }) => (
  <div className="bg-white p-4 rounded-lg border border-gray-200">
    <div className="flex justify-between items-start mb-2">
      <h3 className="font-semibold text-gray-800">{review.hotelName}</h3>
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
        ))}
      </div>
    </div>
    <p className="text-sm text-gray-600 mb-2">"{review.text}"</p>
    <p className="text-xs text-gray-400">{review.date}</p>
  </div>
);

export default ProfileReviewCard;
