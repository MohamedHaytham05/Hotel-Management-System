import React from "react";
import "swiper/css/navigation";
import "swiper/css/pagination";
import 'swiper/css';
import { Navigation, Pagination } from "swiper/modules";
import { Swiper, SwiperSlide } from 'swiper/react';

export default function Hero1() {
  return (
    <>
      <Swiper
        className="w-full overflow-visible"
        spaceBetween={0}
        slidesPerView={1}
        navigation
        pagination={{ clickable: true }}
        modules={[Navigation, Pagination]}
        style={{ height: "400px" }}
      >
        <SwiperSlide>
          <img src="/type-entertainment-complex-popular-resort-with-pools-water-parks-turkey-with-more-than-5-million-visitors-year-amara-dolce-vita-luxury-hotel-resort-tekirova-kemer.jpg" alt="Htl 1" className="w-full h-full object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/swimming-pool.jpg" alt="Htl 2" className="w-full h-full object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/aerial-shot-aria-hotel-las-vegas.jpg" alt="Htl 3" className="w-full h-full object-cover" />
        </SwiperSlide>
      </Swiper>

      <style>{`
        .swiper-button-next,.swiper-button-prev {color: black !important; background: rgba(255, 255, 255, 0.7); width: 44px; height: 44px; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.15); transition: all 0.2s;}
        .swiper-button-next:hover,
        .swiper-button-prev:hover {background: white; transform: scale(1.1);}
        .swiper-button-next:after,
        .swiper-button-prev:after {font-size: 22px; font-weight: bold;}
        .swiper-button-prev {left: -22px !important;}
        .swiper-button-next {right: -22px !important;}
        .swiper-pagination-bullet-active {background: black !important;}
        @media (max-width: 768px) {.swiper-button-prev {left: 5px !important;}.swiper-button-next {right: 5px !important;}}
        `}</style>
    </>
  );
}
