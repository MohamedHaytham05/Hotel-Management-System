  import React from 'react';
  import { Link } from 'react-router-dom';
  import { Mail, Phone } from 'lucide-react';

  export default function Footer() {
    return (
      <footer className="bg-[#030712] text-gray-200 py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start gap-8">
            <div>
              <h3 className="text-xl font-semibold text-white mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/About" className="text-gray-400 hover:text-yellow-500 transition">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link to="/terms" className="text-gray-400 hover:text-yellow-500 transition">
                    Terms & Conditions
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-4">Customer Support</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <Mail size={18} className="text-yellow-500" />
                  <a href="mailto:support@hotlio.com" className="text-gray-400 hover:text-yellow-500 transition">
                    support@hotlio.com
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <Phone size={18} className="text-yellow-500" />
                  <a href="tel:+2000000000000" className="text-gray-400 hover:text-yellow-500 transition">
                    +20 000 000 0000
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-6 text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Hotlio. All rights reserved.
          </div>
        </div>
      </footer>
    );
  }
