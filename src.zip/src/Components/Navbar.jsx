﻿import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell, User } from 'lucide-react';
import { useNotifications } from '../Context/NotificationContext';
import { useAuth } from '../Context/AuthContext';

export default function Navbar() {
  const { notifications } = useNotifications();
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);
  const notifDropdownRef = useRef(null);
  const notifIconRef = useRef(null);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const profileCloseTimeoutRef = useRef(null);
  const profileDropdownRef = useRef(null);
  const profileIconRef = useRef(null);

  useEffect(() => {
    return () => {
      if (profileCloseTimeoutRef.current) clearTimeout(profileCloseTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    function handleClickOutside(event) {
      if (notifDropdownRef.current && !notifDropdownRef.current.contains(event.target) && notifIconRef.current && !notifIconRef.current.contains(event.target)) {
        setIsNotifDropdownOpen(false);
      }
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target) && profileIconRef.current && !profileIconRef.current.contains(event.target)) {
        setIsProfileDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleProfileMouseEnter = () => {
    if (profileCloseTimeoutRef.current) clearTimeout(profileCloseTimeoutRef.current);
    setIsProfileDropdownOpen(true);
  };

  const handleProfileMouseLeave = () => {
    profileCloseTimeoutRef.current = setTimeout(() => setIsProfileDropdownOpen(false), 100);
  };

  const handleNotifClick = () => {
    setIsNotifDropdownOpen((prev) => !prev);
  };

  const recentNotifications = notifications
    .filter((notification) => !notification.read)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 3);

  async function handleLogout() {
    await logout();
    setIsProfileDropdownOpen(false);
    navigate('/');
  }

  return (
    <nav className="flex justify-between items-center bg-[#0b1a2b] px-8 py-3">
      <Link to="/" className="text-white text-2xl font-bold">Hotlio</Link>
      <ul className="flex gap-4 items-center">
        <li>
          <Link to="/About" className="px-5 py-2 rounded-full bg-gray-700 text-gray-200 transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 focus:ring-offset-[#0b1a2b]">About Us</Link>
        </li>

        {!isAuthenticated && (
          <>
            <li>
              <Link to="/Login" className="px-5 py-2 rounded-full bg-gray-700 text-gray-200 transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 focus:ring-offset-[#0b1a2b]">Login</Link>
            </li>
            <li>
              <Link to="/signup" className="px-5 py-2 rounded-full bg-yellow-500 text-white transition-all duration-300 hover:bg-yellow-400 hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 focus:ring-offset-[#0b1a2b]">Sign Up</Link>
            </li>
          </>
        )}

        {isAuthenticated && (
          <>
            <li>
              <Link to="/Hotels" className="px-5 py-2 rounded-full bg-gray-700 text-gray-200 transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 focus:ring-offset-[#0b1a2b]">Booking</Link>
            </li>

            <li className="relative">
              <div ref={notifIconRef} onClick={handleNotifClick}>
                <button className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-700 text-gray-200 transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500" title="Notifications" aria-label="Notifications">
                  <Bell size={20} />
                </button>
              </div>
              {isNotifDropdownOpen && (
                <div ref={notifDropdownRef} className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg overflow-hidden z-20">
                  <div className="p-2 border-b border-gray-200">
                    <Link to="/Reviews" className="block px-4 py-2 text-sm text-gray-700 transition-all duration-300 hover:bg-gray-100 hover:text-yellow-500 hover:shadow-[0_0_5px_rgba(255,215,0,0.5)] rounded" onClick={() => setIsNotifDropdownOpen(false)}>Reviews & Rating</Link>
                    <Link to="/notification-history" className="block px-4 py-2 text-sm text-gray-700 transition-all duration-300 hover:bg-gray-100 hover:text-yellow-500 hover:shadow-[0_0_5px_rgba(255,215,0,0.5)] rounded" onClick={() => setIsNotifDropdownOpen(false)}>Notification History</Link>
                  </div>
                  <div className="p-4 text-sm text-gray-500">
                    {recentNotifications.length > 0 ? (
                      <ul className="space-y-2">
                        {recentNotifications.map((notif) => (
                          <li key={notif._id} className="text-gray-700 border-b border-gray-100 pb-2 last:border-0">
                            <p className="font-medium">{notif.message}</p>
                            <p className="text-xs text-gray-400">{new Date(notif.date).toLocaleDateString()}</p>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-center">No recent notifications</p>
                    )}
                  </div>
                </div>
              )}
            </li>

            <li className="relative">
              <div ref={profileIconRef} onMouseEnter={handleProfileMouseEnter} onMouseLeave={handleProfileMouseLeave}>
                <Link to="/Profile" className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-700 text-gray-200 transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] focus:outline-none focus:ring-2 focus:ring-yellow-500" title="Profile"><User size={20} /></Link>
              </div>
              {isProfileDropdownOpen && (
                <div ref={profileDropdownRef} onMouseEnter={handleProfileMouseEnter} onMouseLeave={handleProfileMouseLeave} className="absolute right-0 mt-2 w-52 bg-white rounded-lg shadow-lg overflow-hidden z-20">
                  <div className="p-2">
                    <div className="px-4 py-2 text-sm text-gray-700 border-b border-gray-100">
                      Signed in as <span className="font-semibold">{user?.name}</span>
                    </div>
                    <Link to={isAdmin ? "/Admin" : "/Profile"} className="block px-4 py-2 text-sm text-gray-700 transition-all duration-300 hover:bg-gray-100 hover:text-yellow-500 hover:shadow-[0_0_5px_rgba(255,215,0,0.5)] rounded" onClick={() => setIsProfileDropdownOpen(false)}>{isAdmin ? "Admin Panel" : "Profile"}</Link>
                    <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-sm text-gray-700 transition-all duration-300 hover:bg-gray-100 hover:text-yellow-500 hover:shadow-[0_0_5px_rgba(255,215,0,0.5)] rounded">
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}
