import React from 'react';
import { Camera, Trash2 } from 'lucide-react';

const ProfileAvatar = ({ name, image, onImageChange, onImageRemove }) => {
  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="relative group">
      <div className="w-24 h-24 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold overflow-hidden">
        {image ? (
          <img src={image} alt={name} className="w-full h-full object-cover" />
        ) : (
          getInitials(name)
        )}
      </div>
      <div className="absolute -bottom-2 right-0 flex gap-2 opacity-0 group-hover:opacity-100 transition">
        {image && (
          <button
            onClick={onImageRemove}
            className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
            title="Remove image"
            type="button"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
          </button>
        )}
        <button
          onClick={onImageChange}
          className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
          title="Change image"
          type="button"
        >
          <Camera className="w-4 h-4 text-gray-600" />
        </button>
      </div>
    </div>
  );
};

export default ProfileAvatar;
