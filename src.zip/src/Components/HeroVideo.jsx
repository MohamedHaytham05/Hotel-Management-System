import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default function HeroVideo() {
  const navigate = useNavigate();
  const SearchSchema = Yup.object().shape({
    location: Yup.string()
      .matches(/^[A-Za-z\s]+$/, 'Only letters and spaces are allowed')
      .required('Please enter the required location'),
  });
  return (
    <div className="relative h-[500px] overflow-hidden">
      <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover" src="/Effective Videos for Hotel Marketing _ Hotel Felix.mp4"/>
      <div className="absolute inset-0 bg-black/40" />
      <div className="relative container mx-auto px-6 h-full flex flex-col justify-center items-center text-center text-white z-10">
        <h1 className="text-5xl md:text-6xl font-bold mb-4">Welcome to Hotlio</h1>
        <p className="text-xl mb-8">Enjoy our recommended stays for every moment</p>
        <Formik
          initialValues={{ location: '' }}
          validationSchema={SearchSchema}
          onSubmit={(values) => {
            navigate(`/Hotels?location=${encodeURIComponent(values.location)}`);
          }}
        >
          {({ isSubmitting }) => (
            <Form className="bg-white p-4 rounded-lg shadow-lg w-full max-w-4xl flex flex-col md:flex-row gap-2 items-start">
              <div className="flex-1 w-full">
                <Field type="text" name="location" placeholder="Where are you going?" className="w-full p-3 border rounded-md text-gray-800 focus:outline-none focus:ring-2 focus:ring-yellow-500"/>
                <ErrorMessage name="location" component="div" className="text-red-500 text-sm mt-1 text-left" />
              </div>
              <button type="submit" disabled={isSubmitting} className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-6 py-3 rounded-md transition whitespace-nowrap">
                Search
              </button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}
