function QuickStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-linear-to-r from-blue-600 to-blue-700 text-white p-6 rounded-xl shadow-lg">
        <p className="text-sm opacity-90 mb-1">Today's Check-ins</p>
        <p className="text-3xl font-bold mb-2">24</p>
        <div className="w-full bg-blue-500 rounded-full h-2">
          <div className="bg-white h-2 rounded-full" style={{ width: '60%' }}></div>
        </div>
        <p className="text-xs opacity-75 mt-2">60% of total capacity</p>
      </div>
      <div className="bg-linear-to-r from-green-600 to-green-700 text-white p-6 rounded-xl shadow-lg">
        <p className="text-sm opacity-90 mb-1">Today's Check-outs</p>
        <p className="text-3xl font-bold mb-2">18</p>
        <div className="w-full bg-green-500 rounded-full h-2">
          <div className="bg-white h-2 rounded-full" style={{ width: '45%' }}></div>
        </div>
        <p className="text-xs opacity-75 mt-2">45% completed</p>
      </div>
      <div className="bg-linear-to-r from-purple-600 to-purple-700 text-white p-6 rounded-xl shadow-lg">
        <p className="text-sm opacity-90 mb-1">Occupancy Rate</p>
        <p className="text-3xl font-bold mb-2">78%</p>
        <div className="w-full bg-purple-500 rounded-full h-2">
          <div className="bg-white h-2 rounded-full" style={{ width: '78%' }}></div>
        </div>
        <p className="text-xs opacity-75 mt-2">↑ 12% from yesterday</p>
      </div>
    </div>
  );
}
export default QuickStats;
