import React, { useState } from "react";
import { useHotelSearch } from "../Context/HotelSearchContext";

function SearchForm() {
  const { setSelectedCity } = useHotelSearch();
  const [destination, setDestination] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const handleSearch = (e) => { e.preventDefault(); setSelectedCity(destination); console.log("Destination:", destination); console.log("Check In:", checkIn); console.log("Check Out:", checkOut); };
  return (
    <div className="bg-white-600 p-6 flex justify-center">
      <form onSubmit={handleSearch} className="bg-white p-6 rounded-xl shadow-lg flex gap-4">
        <div>
          <label className="block">Destination</label>
          <select className="border p-2 rounded" value={destination} onChange={(e) => setDestination(e.target.value)}>
            <option value="">Choose city</option>
            <option value="Cairo">Cairo</option>
            <option value="Alexandria">Alexandria</option>
            <option value="Hurghada">Hurghada</option>
            <option value="Sharm El Sheikh">Sharm El Sheikh</option>
            <option value="Dahab">Dahab</option>
          </select>
        </div>
        <div>
          <label className="block">Check In</label>
          <input type="date" className="border p-2 rounded" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} />
        </div>
        <div>
          <label className="block">Check Out</label>
          <input type="date" className="border p-2 rounded" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
        </div>
        <div className="flex items-end">
          <button className="bg-blue-600 text-white px-6 py-2 rounded">Search</button>
        </div>
      </form>
    </div>
  );
}
export default SearchForm;
