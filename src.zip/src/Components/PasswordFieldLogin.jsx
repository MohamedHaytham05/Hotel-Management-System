import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
const PasswordFieldLogin = ({ name, value, onChange, error, placeholder }) => {
  const [showPassword, setShowPassword] = useState(false);
  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">Password</label>
      <div className="relative">
        <input id={name} name={name} type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={value} onChange={onChange} className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition pr-10 ${error ? 'border-red-500' : 'border-gray-300'}`} placeholder={placeholder} />
        <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 hover:text-gray-700">{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button>
      </div>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
    </div>
  );
};
export default PasswordFieldLogin;
