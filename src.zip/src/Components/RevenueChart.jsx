import { BarChart, TrendingUp } from 'lucide-react';
import React from 'react';
import { useAdminDashboard } from "../Context/AdminDashboardContext";

function RevenueChart() {
  const { revenuePeriod, setRevenuePeriod, revenueData } = useAdminDashboard();
  const currentRevenueData = revenueData[revenuePeriod];
  const maxRevenue = Math.max(...currentRevenueData.map(d => d.amount));
  const getRevenueTrend = () => { switch(revenuePeriod) { case '7days': return '+23%'; case '30days': return '+18%'; case '3months': return '+15%'; default: return '+20%'; } };
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2"><BarChart size={20} className="text-blue-500" /> Revenue Overview</h3>
        <select value={revenuePeriod} onChange={(e) => setRevenuePeriod(e.target.value)} className="text-sm border rounded-lg px-3 py-2 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"><option value="7days">Last 7 days</option><option value="30days">Last 30 days</option><option value="3months">Last 3 months</option></select>
      </div>
      <div className="h-64 flex items-end justify-between gap-2 mb-4">
        {currentRevenueData.map((data, index) => (
          <div key={index} className="flex flex-col items-center w-full">
            <div className="w-full flex justify-center">
              <div className="w-8 bg-linear-to-t from-blue-500 to-blue-400 rounded-t-lg transition-all hover:from-blue-600 hover:to-blue-500 cursor-pointer group relative" style={{ height: `${(data.amount / maxRevenue) * 180}px`, minHeight: '30px' }}>
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs rounded px-2 py-1 whitespace-nowrap transition-opacity">${data.amount.toLocaleString()}</div>
                <div className="text-xs text-white text-center pt-1 font-bold">${(data.amount/1000).toFixed(1)}k</div>
              </div>
            </div>
            <span className="text-xs text-gray-600 mt-2 font-medium">{data.day}</span>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-center gap-6 mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-blue-500 rounded-full"></div><span className="text-sm text-gray-600">Daily Revenue</span></div>
        <div className="flex items-center gap-2"><TrendingUp size={16} className="text-green-500" /><span className="text-sm text-gray-600">{getRevenueTrend()} vs last period</span></div>
      </div>
    </div>
  );
}
export default RevenueChart;
