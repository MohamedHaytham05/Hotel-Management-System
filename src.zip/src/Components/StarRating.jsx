import React from 'react';
import { Star } from 'lucide-react';

function StarRating({ rating, setRating }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => setRating(star)}
          className={`p-1 rounded cursor-pointer transition-all border-none bg-transparent text-xl ${
            star <= rating
              ? 'text-yellow-400 fill-current shadow-sm'
              : 'text-gray-300 stroke-current'
          } hover:text-yellow-500 hover:scale-110 hover:shadow-md`}
          aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
        >
          <Star />
        </button>
      ))}
    </div>
  );
}

export default StarRating;
