import * as Icons from 'lucide-react';
import React from 'react';
import { useAdminDashboard } from "../Context/AdminDashboardContext";

function StatsCards() {
  const { stats } = useAdminDashboard();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => {
        const Icon = Icons[stat.icon];
        return (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-14 h-14 ${stat.color} rounded-xl flex items-center justify-center text-white shadow-lg`}>
                <Icon size={28} />
              </div>
              <span className="text-green-500 bg-green-50 px-2 py-1 rounded-full text-sm font-medium">
                {stat.change}
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-1">{stat.label}</p>
            <p className="text-3xl font-bold text-gray-800">{stat.value}</p>
          </div>
        );
      })}
    </div>
  );
}

export default StatsCards;
