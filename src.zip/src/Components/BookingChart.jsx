import { PieChart } from 'lucide-react';
import { useAdminDashboard } from "../Context/AdminDashboardContext";

function BookingChart() {
  const { bookingPeriod, setBookingPeriod, bookingData } = useAdminDashboard();
  const currentBookingData = bookingData[bookingPeriod];
  const totalBookings = currentBookingData.reduce((acc, curr) => acc + curr.count, 0);
  const getBookingGrowth = () => { switch(bookingPeriod) { case 'today': return '+8%'; case 'week': return '+12%'; case 'month': return '+18%'; default: return '+15%'; } };
  const getStatusColor = (color) => { switch(color) { case 'bg-green-500': return '#10b981'; case 'bg-yellow-500': return '#f59e0b'; case 'bg-red-500': return '#ef4444'; case 'bg-blue-500': return '#3b82f6'; default: return '#3b82f6'; } };
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2"><PieChart size={20} className="text-green-500" /> Booking Statistics</h3>
        <select value={bookingPeriod} onChange={(e) => setBookingPeriod(e.target.value)} className="text-sm border rounded-lg px-3 py-2 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500"><option value="today">Today</option><option value="week">This week</option><option value="month">This month</option></select>
      </div>
      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="relative w-40 h-40">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">{currentBookingData.map((item, index) => { const previousTotal = currentBookingData.slice(0, index).reduce((acc, curr) => acc + curr.count, 0); return (<circle key={index} cx="50" cy="50" r="40" fill="none" stroke={getStatusColor(item.color)} strokeWidth="12" strokeDasharray={`${(item.count / totalBookings) * 251} 251`} strokeDashoffset={-((previousTotal / totalBookings) * 251)} className="transition-all duration-700 ease-in-out" />); })}</svg>
          <div className="absolute inset-0 flex items-center justify-center flex-col"><span className="text-2xl font-bold text-gray-800">{totalBookings}</span><span className="text-xs text-gray-500">Total</span></div>
        </div>
        <div className="flex-1 space-y-3">{currentBookingData.map((item, index) => (<div key={index} className="flex items-center justify-between hover:bg-gray-50 p-2 rounded-lg transition-colors"><div className="flex items-center gap-2"><div className={`w-3 h-3 rounded-full ${item.color}`}></div><span className="text-sm text-gray-600">{item.status}</span></div><div className="flex items-center gap-4"><span className="text-sm font-semibold text-gray-800">{item.count}</span><span className="text-xs text-gray-500 w-12">{((item.count / totalBookings) * 100).toFixed(1)}%</span></div></div>))}</div>
      </div>
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-gray-100">
        <div className="text-center"><p className="text-xs text-gray-500">Avg. Daily</p><p className="text-lg font-bold text-gray-800">{Math.round(totalBookings / (bookingPeriod === 'today' ? 1 : bookingPeriod === 'week' ? 7 : 30))}</p></div>
        <div className="text-center"><p className="text-xs text-gray-500">Peak Day</p><p className="text-lg font-bold text-gray-800">{bookingPeriod === 'today' ? 'Now' : bookingPeriod === 'week' ? 'Fri' : 'Week 3'}</p></div>
        <div className="text-center"><p className="text-xs text-gray-500">Growth</p><p className="text-lg font-bold text-green-600">{getBookingGrowth()}</p></div>
      </div>
    </div>
  );
}

export default BookingChart;
