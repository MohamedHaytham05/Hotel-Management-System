import React from 'react';
import { CheckCircle, Calendar, XCircle, Clock } from 'lucide-react';

const BookingCard = ({ booking }) => {
  const statusColors = {
    completed: 'bg-green-100 text-green-600',
    upcoming: 'bg-blue-100 text-blue-600',
    cancelled: 'bg-red-100 text-red-600',
    pending: 'bg-yellow-100 text-yellow-600'
  };

  const statusIcons = {
    completed: CheckCircle,
    upcoming: Calendar,
    cancelled: XCircle,
    pending: Clock
  };

  const StatusIcon = statusIcons[booking.status] || Clock;

  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 hover:shadow-md transition">
      <div className="flex justify-between items-start mb-3">
        <h3 className="font-semibold text-gray-800">{booking.hotelName}</h3>
        <span className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${statusColors[booking.status]}`}>
          <StatusIcon className="w-3 h-3" />
          {booking.status}
        </span>
      </div>
      <p className="text-sm text-gray-500 mb-2">{booking.location}</p>
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-600">
          <span className="font-medium">{booking.dates}</span> • {booking.nights} nights
        </div>
        <p className="font-bold text-blue-600">{booking.price} EGP</p>
      </div>
    </div>
  );
};

export default BookingCard;
