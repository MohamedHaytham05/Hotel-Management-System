function ReviewCard({ review }) {
  const reviewerName = review.name || review.userId?.name || "Guest User";

  return (
    <div
      style={{
        background: "white",
        padding: "20px",
        borderRadius: "10px",
        boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
        marginBottom: "20px"
      }}
    >
      <h3>{reviewerName}</h3>
      <div className="flex gap-1 mb-2">
        {[1, 2, 3, 4, 5].map((_, i) => (
          <div key={i} className={`w-5 h-5 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}>
            ★
          </div>
        ))}
      </div>
      <p>{review.text}</p>
    </div>
  );
}

export default ReviewCard;
