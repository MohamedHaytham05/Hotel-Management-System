import React from 'react';
import { Link } from 'react-router-dom';

export default function CallToAction() {
  return (
    <section className="py-16 bg-[#0b1a2b]">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Get Special Offers & Deals</h2>
        <p className="text-xl text-gray-200 mb-8">Get the best hotel offers and discounts directly to your inbox simply signing up.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/Signup" className="px-8 py-4 bg-gray-700 text-gray-200 font-semibold rounded-full text-lg transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] hover:scale-105 focus:outline-none focus:ring-2 focus:ring-yellow-500">
            Sign Up Now
          </Link>
          <Link to="/Login" className="px-8 py-4 bg-gray-700 text-gray-200 font-semibold rounded-full text-lg transition-all duration-300 hover:bg-yellow-500 hover:text-white hover:shadow-[0_0_10px_gold] hover:scale-105 focus:outline-none focus:ring-2 focus:ring-yellow-500">
            Log In
          </Link>
        </div>
      </div>
    </section>
  );
}
