import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../Context/AuthContext';

export default function FeaturedHotels() {
  const [featuredHotels, setFeaturedHotels] = useState([]);
  const [userFavorites, setUserFavorites] = useState(new Set());
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    async function loadHotels() {
      try {
        const hotels = await apiFetch('/api/hotels');
        setFeaturedHotels(hotels.slice(0, 4));
      } catch {
        setFeaturedHotels([]);
      }
    }

    loadHotels();
  }, [isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    async function loadFavorites() {
      try {
        const data = await apiFetch('/api/favorites');
        const favorites = new Set(data.favorites.map(f => f.hotelId._id));
        setUserFavorites(favorites);
      } catch {

      }
    }

    loadFavorites();
  }, [isAuthenticated, user]);

  const handleToggleFavorite = async (hotelId) => {
    if (!isAuthenticated) {
      alert('Please login to favorite hotels');
      return;
    }

    try {
      await apiFetch('/api/favorites/toggle', {
        method: 'POST',
        body: JSON.stringify({ hotelId })
      });

      setUserFavorites(prev => {
        const newSet = new Set(prev);
        if (newSet.has(hotelId)) {
          newSet.delete(hotelId);
        } else {
          newSet.add(hotelId);
        }
        return newSet;
      });
    } catch (error) {
      console.error('Toggle favorite failed:', error.message);
    }
  };

  const isFavorite = (hotelId) => userFavorites.has(hotelId);

  return (
    <div className="container mx-auto px-6 py-16">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800">Recommended Stays</h2>
        <Link to="/Hotels" className="text-yellow-600 hover:text-yellow-700 font-semibold">View All</Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {featuredHotels.map((hotel) => (
          <div key={hotel._id} className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition relative">
            <img src={hotel.images?.[0]} alt={hotel.name} className="w-full h-48 object-cover group-hover:scale-105 transition duration-300 border-[3px] border-black" />
            <div className="p-4">
              <h3 className="text-xl font-semibold text-gray-800 mb-1">{hotel.name}</h3>
              <p className="text-gray-600 mb-2">{hotel.location}</p>
              <div className="flex justify-between items-center gap-2">
                <span className="text-yellow-600 font-bold">{hotel.price} L.E/Day</span>
                <div className="flex gap-2">
                  <Link
                    to="/Book"
                    state={hotel}
                    className="bg-black text-white font-sans px-4 py-2 rounded-md transition-all duration-300 hover:bg-gray-600 hover:outline hover:outline-2 hover:outline-white text-sm"
                  >
                    Book Now
                  </Link>
                  <button
                    onClick={() => handleToggleFavorite(hotel._id)}
className={`p-2 rounded-md transition-all duration-300 hover:scale-110 active:scale-90 animate-pulse ${
                      isFavorite(hotel._id)
                        ? 'text-red-500 bg-red-50 hover:bg-red-100'
                        : 'text-gray-400 hover:text-red-500 hover:bg-gray-50'
                    }`}
                    title={isFavorite(hotel._id) ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Heart className={`w-5 h-5 ${isFavorite(hotel._id) ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
