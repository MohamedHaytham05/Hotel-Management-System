import { LogOut, Hotel, Plus } from 'lucide-react';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { apiFetch } from '../lib/api';

const PUBLIC_IMAGES = [
  '1.jpg',
  '2.jpg',
  '94190040.png',
  '484416516.jpg',
  'aerial-shot-aria-hotel-las-vegas.jpg',
  'caimn-grounds-0019.png',
  'f0dc84d39484-74574517_4K.png',
  'swimming-pool.jpg',
  'type-entertainment-complex-popular-resort-with-pools-water-parks-turkey-with-more-than-5-million-visitors-year-amara-dolce-vita-luxury-hotel-resort-tekirova-kemer.jpg'
];

function getRandomImage() {
  const randomIndex = Math.floor(Math.random() * PUBLIC_IMAGES.length);
  return '/' + PUBLIC_IMAGES[randomIndex];
}

function TopBar() {
  const [showModal, setShowModal] = useState(false);
  const [hotelData, setHotelData] = useState({
    name: '',
    location: '',
    price: '',
    rating: '',
    facilities: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setMessage('');

    try {
      const payload = {
        name: hotelData.name,
        location: hotelData.location,
        price: Number(hotelData.price),
        rating: Number(hotelData.rating) || 0,
        facilities: hotelData.facilities.split(',').map(f => f.trim()).filter(Boolean),
        images: [getRandomImage()]
      };

      await apiFetch('/api/hotels', {
        method: 'POST',
        body: JSON.stringify(payload)
      });

      setMessage('Hotel added successfully!');
      setHotelData({ name: '', location: '', price: '', rating: '', facilities: '' });
      setTimeout(() => {
        setShowModal(false);
        setMessage('');
      }, 1500);
    } catch (error) {
      setMessage(error.message || 'Failed to add hotel');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <div className='bg-white shadow-sm p-4 flex justify-between items-center'>
        <div className='flex items-center gap-3'>
          <h1 className='text-2xl font-bold text-blue-600'>Admin Dashboard</h1>
          <span className='bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full'>Live</span>
        </div>
        <div className='flex items-center gap-3'>
          <button
            onClick={() => setShowModal(true)}
            className='flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition'
          >
            <Plus size={18} />
            <span>Add Hotel</span>
          </button>
          <Link to='/' className='flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md text-gray-700 transition'>
            <LogOut size={18} /><span>Logout</span>
          </Link>
        </div>
      </div>

      {showModal && (
        <div className='fixed inset-0 bg-gray-900/50 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm'>
          <div className='bg-white rounded-2xl p-8 max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl'>
            <div className='flex justify-between items-center mb-6'>
              <h2 className='text-2xl font-bold text-gray-800 flex items-center gap-2'>
                <Hotel className='text-blue-600' size={28} />
                Add New Hotel
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className='text-gray-400 hover:text-gray-600 text-2xl'
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit} className='space-y-4'>
              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Hotel Name</label>
                <input
                  type='text'
                  required
                  value={hotelData.name}
                  onChange={(e) => setHotelData(prev => ({ ...prev, name: e.target.value }))}
                  className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
                  placeholder='e.g. Nile Ritz-Carlton'
                />
              </div>

              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Location</label>
                <input
                  type='text'
                  required
                  value={hotelData.location}
                  onChange={(e) => setHotelData(prev => ({ ...prev, location: e.target.value }))}
                  className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
                  placeholder='e.g. Cairo'
                />
              </div>

              <div className='grid grid-cols-2 gap-4'>
                <div>
                  <label className='block text-sm font-medium text-gray-700 mb-1'>Price (L.E)</label>
                  <input
                    type='number'
                    required
                    min='0'
                    value={hotelData.price}
                    onChange={(e) => setHotelData(prev => ({ ...prev, price: e.target.value }))}
                    className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
                    placeholder='1800'
                  />
                </div>
                <div>
                  <label className='block text-sm font-medium text-gray-700 mb-1'>Rating (0-5)</label>
                  <input
                    type='number'
                    min='0'
                    max='5'
                    step='0.1'
                    value={hotelData.rating}
                    onChange={(e) => setHotelData(prev => ({ ...prev, rating: e.target.value }))}
                    className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
                    placeholder='4.5'
                  />
                </div>
              </div>

              <div>
                <label className='block text-sm font-medium text-gray-700 mb-1'>Facilities (comma separated)</label>
                <input
                  type='text'
                  value={hotelData.facilities}
                  onChange={(e) => setHotelData(prev => ({ ...prev, facilities: e.target.value }))}
                  className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
                  placeholder='Wifi, Pool, Breakfast, Parking'
                />
              </div>

              {message && (
                <p className={'text-sm ' + (message.includes('success') ? 'text-green-600' : 'text-red-600')}>
                  {message}
                </p>
              )}

              <div className='flex gap-3 pt-2'>
                <button
                  type='submit'
                  disabled={submitting}
                  className='flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition disabled:bg-gray-400'
                >
                  {submitting ? 'Adding...' : 'Add Hotel'}
                </button>
                <button
                  type='button'
                  onClick={() => setShowModal(false)}
                  className='flex-1 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg font-medium transition'
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

export default TopBar;
