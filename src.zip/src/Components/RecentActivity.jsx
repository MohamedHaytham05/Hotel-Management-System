import { Clock } from 'lucide-react';
import { useAdminDashboard } from "../Context/AdminDashboardContext";

function RecentActivity() {
  const { recentActivity: activities } = useAdminDashboard();

  const getStatusClass = (status) => {
    switch(status) {
      case 'completed': return 'bg-green-100 text-green-600';
      case 'pending': return 'bg-yellow-100 text-yellow-600';
      case 'in-progress': return 'bg-blue-100 text-blue-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm mb-8">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <Clock size={20} className="text-purple-500" /> Recent Activity
      </h3>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 text-gray-600 font-medium">Action</th>
              <th className="text-left py-3 text-gray-600 font-medium">User</th>
              <th className="text-left py-3 text-gray-600 font-medium">Time</th>
              <th className="text-left py-3 text-gray-600 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {activities.map(activity => (
              <tr key={activity.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="py-3 font-medium text-gray-800">{activity.action}</td>
                <td className="py-3 text-gray-600">{activity.user}</td>
                <td className="py-3 text-gray-500">{activity.time}</td>
                <td className="py-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusClass(activity.status)}`}>
                    {activity.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default RecentActivity;
