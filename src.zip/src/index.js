require('dotenv').config();
const express = require('express');
const corsOptions = require('./middleware/cors');
const connectDB = require('./db');
const logger = require('./middleware/logger');

const authRouter = require('./routes/auth');
const usersRouter = require('./routes/users');
const hotelsRouter = require('./routes/hotels');
const bookingsRouter = require('./routes/bookings');
const reviewsRouter = require('./routes/reviews');
const notificationsRouter = require('./routes/notifications');
const favoritesRouter = require('./routes/favorites');
const adminRouter = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(require('cors')(corsOptions));
app.use(logger);

app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/hotels', hotelsRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/reviews', reviewsRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/favorites', favoritesRouter);
app.use('/api/admin', adminRouter);

app.get('/', (_req, res) => {
  res.status(200).send('Server is running');
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

connectDB().catch((error) => {
  console.error('MongoDB connection failed:', error.message);
  console.error('Server is still running, but database-backed features may not work until MongoDB is reachable.');
});
