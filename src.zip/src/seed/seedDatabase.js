const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Hotel = require('../models/Hotel');
const Booking = require('../models/Booking');
const Review = require('../models/Review');
const Notification = require('../models/Notification');
const Activity = require('../models/Activity');

async function upsertUser(user) {
  const existing = await User.findOne({ email: user.email });

  const hashedPassword = await bcrypt.hash(user.password, 10);

  if (existing) {
    existing.password = hashedPassword;
    await existing.save();
    return existing;
  }

  return User.create({ ...user, password: hashedPassword });
}

async function upsertHotel(hotel) {
  const existing = await Hotel.findOne({ name: hotel.name });
  if (existing) return existing;

  return Hotel.create(hotel);
}

async function upsertBooking(booking) {
  const existing = await Booking.findOne({
    userId: booking.userId,
    hotelId: booking.hotelId,
    dates: booking.dates,
  });
  if (existing) return existing;

  return Booking.create(booking);
}

async function upsertReview(review) {
  const existing = await Review.findOne({
    userId: review.userId,
    hotelId: review.hotelId,
    text: review.text,
  });
  if (existing) return existing;

  return Review.create(review);
}

async function upsertNotification(notification) {
  const existing = await Notification.findOne({
    userId: notification.userId,
    message: notification.message,
  });
  if (existing) return existing;

  return Notification.create(notification);
}

async function seedDatabase() {
  const adminUser = await upsertUser({
    name: 'Admin User',
    email: 'admin@hotlio.com',
password: 'Admin12@',
    city: 'Cairo',
    phone: '+20 100 000 0001',
    role: 'admin',
  });

const ahmedUser = await upsertUser({
    name: 'Ahmed Mohamed',
    email: 'ahmed@example.com',
    password: 'Pass123@',
    city: 'Cairo',
    phone: '+20 100 000 0002',
    role: 'user',
  });

const saraUser = await upsertUser({
    name: 'Sara Ali',
    email: 'sara@example.com',
    password: 'Pass123@',
    city: 'Hurghada',
    phone: '+20 100 000 0003',
    role: 'user',
  });

  const nileHotel = await upsertHotel({
    name: 'Nile Ritz-Carlton',
    location: 'Cairo',
    price: 1800,
    rating: 4.8,
    images: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1200&auto=format&fit=crop',
    ],
    facilities: ['Wifi', 'Pool', 'Breakfast', 'Parking'],
  });

  const starResort = await upsertHotel({
    name: 'Star Resort',
    location: 'Hurghada',
    price: 2200,
    rating: 4.6,
    images: [
      'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=1200&auto=format&fit=crop',
    ],
    facilities: ['Wifi', 'Beach Access', 'Spa', 'Breakfast'],
  });

  const mountainView = await upsertHotel({
    name: 'Mountain View Lodge',
    location: 'Sharm El Sheikh',
    price: 1600,
    rating: 4.4,
    images: [
      'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?q=80&w=1200&auto=format&fit=crop',
    ],
    facilities: ['Wifi', 'Airport Shuttle', 'Breakfast'],
  });

  await upsertBooking({
    userId: ahmedUser._id,
    hotelId: nileHotel._id,
    dates: '2026-05-10 to 2026-05-13',
    nights: 3,
    price: 5400,
    roomType: 'Double Room',
    adults: 2,
    children: 0,
    status: 'completed',
  });

  await upsertBooking({
    userId: saraUser._id,
    hotelId: starResort._id,
    dates: '2026-06-01 to 2026-06-05',
    nights: 4,
    price: 8800,
    roomType: 'Suite',
    adults: 2,
    children: 1,
    status: 'upcoming',
  });

  await upsertBooking({
    userId: ahmedUser._id,
    hotelId: mountainView._id,
    dates: '2026-07-12 to 2026-07-14',
    nights: 2,
    price: 3200,
    roomType: 'Single Room',
    adults: 1,
    children: 0,
    status: 'pending',
  });

  await upsertReview({
    userId: ahmedUser._id,
    hotelId: nileHotel._id,
    rating: 5,
    text: 'Amazing hotel and very clean rooms with excellent service.',
  });

  await upsertReview({
    userId: saraUser._id,
    hotelId: starResort._id,
    rating: 4,
    text: 'Great location and friendly staff with lovely sea views.',
  });

  await upsertReview({
    userId: ahmedUser._id,
    hotelId: mountainView._id,
    rating: 4,
    text: 'Comfortable stay with peaceful atmosphere and helpful team.',
  });

  await upsertNotification({
    userId: ahmedUser._id,
    message: 'Your booking at Nile Ritz-Carlton has been confirmed.',
    read: false,
  });

  await upsertNotification({
    userId: saraUser._id,
    message: 'Your payment for Star Resort was received successfully.',
    read: true,
  });

  await upsertNotification({
    userId: ahmedUser._id,
    message: 'Your recent review has been published.',
    read: false,
  });

  const Favorite = require('../models/Favorite');
  await Favorite.findOneAndUpdate(
    { userId: ahmedUser._id, hotelId: nileHotel._id },
    { userId: ahmedUser._id, hotelId: nileHotel._id },
    { upsert: true }
  );

  await Favorite.findOneAndUpdate(
    { userId: saraUser._id, hotelId: starResort._id },
    { userId: saraUser._id, hotelId: starResort._id },
    { upsert: true }
  );

  const activityData = [
    { userId: adminUser._id, action: 'LOGIN', details: { note: 'Admin login' } },
    { userId: ahmedUser._id, action: 'BOOKING_CREATED', details: { hotel: 'Nile Ritz-Carlton', dates: '2026-05-10 to 2026-05-13' } },
    { userId: saraUser._id, action: 'BOOKING_CREATED', details: { hotel: 'Star Resort', dates: '2026-06-01 to 2026-06-05' } },
    { userId: ahmedUser._id, action: 'REVIEW_POSTED', details: { hotel: 'Nile Ritz-Carlton', rating: 5 } },
    { userId: saraUser._id, action: 'REVIEW_POSTED', details: { hotel: 'Star Resort', rating: 4 } },
    { userId: ahmedUser._id, action: 'FAVORITE_TOGGLED', details: { hotel: 'Nile Ritz-Carlton', action: 'added' } },
    { userId: saraUser._id, action: 'FAVORITE_TOGGLED', details: { hotel: 'Star Resort', action: 'added' } },
    { userId: adminUser._id, action: 'HOTEL_CREATED', details: { hotel: 'Nile Ritz-Carlton', location: 'Cairo' } },
    { userId: adminUser._id, action: 'HOTEL_CREATED', details: { hotel: 'Star Resort', location: 'Hurghada' } },
  ];

  for (const act of activityData) {
    const existing = await Activity.findOne({ userId: act.userId, action: act.action, 'details.hotel': act.details.hotel });
    if (!existing) {
      await Activity.create(act);
    }
  }

  return {
    users: [adminUser, ahmedUser, saraUser],
    hotels: [nileHotel, starResort, mountainView],
  };
}

module.exports = seedDatabase;
