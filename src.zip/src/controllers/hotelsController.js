const Hotel = require('../models/Hotel');
const Activity = require('../models/Activity');

exports.getAllHotels = async (req, res) => {
  try {
    const hotels = await Hotel.find();
    res.json(hotels);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getHotelById = async (req, res) => {
  try {
    const hotel = await Hotel.findById(req.params.id);
    if (!hotel) return res.status(404).json({ error: 'Hotel not found' });
    res.json(hotel);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.createHotel = async (req, res) => {
  try {
    const hotel = await Hotel.create(req.body);

    if (req.user && req.user.id) {
      await Activity.create({
        userId: req.user.id,
        action: 'HOTEL_CREATED',
        details: { hotel: hotel.name, location: hotel.location }
      });
    }

    res.status(201).json(hotel);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!hotel) return res.status(404).json({ error: 'Hotel not found' });

    if (req.user && req.user.id) {
      await Activity.create({
        userId: req.user.id,
        action: 'HOTEL_UPDATED',
        details: { hotel: hotel.name, hotelId: hotel._id }
      });
    }

    res.json(hotel);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndDelete(req.params.id);
    if (!hotel) return res.status(404).json({ error: 'Hotel not found' });

    if (req.user && req.user.id) {
      await Activity.create({
        userId: req.user.id,
        action: 'HOTEL_DELETED',
        details: { hotel: hotel.name, hotelId: hotel._id }
      });
    }

    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
