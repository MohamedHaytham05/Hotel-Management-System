const Favorite = require('../models/Favorite');
const Hotel = require('../models/Hotel');
const Activity = require('../models/Activity');
const mongoose = require('mongoose');

exports.toggleFavorite = async (req, res) => {
  try {
    const { hotelId } = req.body;
    const userId = new mongoose.Types.ObjectId(req.user.id);

    if (!mongoose.Types.ObjectId.isValid(hotelId)) {
      return res.status(400).json({ message: 'Invalid hotel ID' });
    }

    const hotel = await Hotel.findById(hotelId);
    if (!hotel) {
      return res.status(404).json({ message: 'Hotel not found' });
    }

    const existingFavorite = await Favorite.findOne({
      userId,
      hotelId
    });

    if (existingFavorite) {
      await Favorite.findByIdAndDelete(existingFavorite._id);
      await Activity.create({
        userId,
        action: 'FAVORITE_TOGGLED',
        details: { hotel: hotel.name, action: 'removed' }
      });
      res.json({
        message: 'Hotel removed from favorites',
        favorited: false
      });
    } else {
      await Favorite.create({ userId, hotelId });
      await Activity.create({
        userId,
        action: 'FAVORITE_TOGGLED',
        details: { hotel: hotel.name, action: 'added' }
      });
      res.json({
        message: 'Hotel added to favorites',
        favorited: true
      });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.getFavorites = async (req, res) => {
  try {
    const isAdmin = req.user && req.user.role === 'admin';
    const userId = new mongoose.Types.ObjectId(req.user.id);

    const query = isAdmin && req.query.admin === 'true' ? {} : { userId };

    const favorites = await Favorite.find(query)
      .populate('userId', 'name email')
      .populate('hotelId', 'name location price rating images')
      .sort('-createdAt')
      .lean();

    res.json({
      favorites,
      count: favorites.length
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.deleteFavorite = async (req, res) => {
  try {
    const isAdmin = req.user && req.user.role === 'admin';
    const query = isAdmin ? { _id: req.params.id } : { _id: req.params.id, userId: new mongoose.Types.ObjectId(req.user.id) };

    const favorite = await Favorite.findOneAndDelete(query);
    if (!favorite) {
      return res.status(404).json({ message: 'Favorite not found' });
    }
    res.json({ message: 'Favorite deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
