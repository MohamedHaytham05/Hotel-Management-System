const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const User = require('../models/User');
const Activity = require('../models/Activity');

exports.register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: errors.array()[0].msg, errors: errors.array() });
    }

    const { name, email, password, city, phone } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashedPassword, city, phone });

    const token = jwt.sign(
      { id: user._id, role: user.role || 'user' },
      process.env.JWT_SECRET || 'fallback-super-secret-jwt-key-change-in-prod',
      { expiresIn: '7d' }
    );

    await Activity.create({
      userId: user._id,
      action: 'USER_REGISTERED',
      details: { email: user.email, name: user.name }
    });

    res.status(201).json({
      message: 'User registered',
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      token
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: errors.array()[0].msg, errors: errors.array() });
    }

    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user._id, role: user.role || 'user' },
      process.env.JWT_SECRET || 'fallback-super-secret-jwt-key-change-in-prod',
      { expiresIn: '7d' }
    );

    await Activity.create({
      userId: user._id,
      action: 'LOGIN',
      details: { email: user.email, name: user.name }
    });

    res.json({
      message: 'Login successful',
      user: { id: user._id, name: user.name, role: user.role || 'user' },
      token
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

exports.updateMe = async (req, res) => {
  try {
    const allowedFields = ['name', 'email', 'city', 'phone'];
    const updates = {};

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    });

    const user = await User.findByIdAndUpdate(
      req.user.id,
      updates,
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) return res.status(404).json({ message: 'User not found' });

    await Activity.create({
      userId: user._id,
      action: 'PROFILE_UPDATED',
      details: { updatedFields: Object.keys(updates) }
    });

    res.json(user);
  } catch (err) {
    res.status(400).json({ message: 'Failed to update profile', error: err.message });
  }
};

exports.logout = async (req, res) => {
  try {
    if (req.user && req.user.id) {
      await Activity.create({
        userId: req.user.id,
        action: 'LOGOUT',
        details: {}
      });
    }
  } catch (err) {

  }
  res.json({ message: 'Logged out successfully (client clear token)' });
};
