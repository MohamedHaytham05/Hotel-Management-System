const Review = require('../models/Review');
const Notification = require('../models/Notification');
const Activity = require('../models/Activity');
const mongoose = require('mongoose');

exports.getReviews = async (req, res) => {
  try {
    const filter = {};
    const isAdmin = req.user && req.user.role === 'admin';

    if (req.query.hotelId) {
      filter.hotelId = req.query.hotelId;
    }

    if (req.query.mine === 'true') {
      if (!req.user) {
        return res.status(401).json({ error: 'Not authenticated' });
      }
      filter.userId = new mongoose.Types.ObjectId(req.user.id);
    } else if (req.query.admin === 'true') {
      if (!isAdmin) {
        return res.status(403).json({ error: 'Admin access required' });
      }

    } else if (!isAdmin) {

      filter.userId = new mongoose.Types.ObjectId(req.user.id);
    }

    const reviews = await Review.find(filter)
      .populate('hotelId')
      .populate('userId', 'name')
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createReview = async (req, res) => {
  try {
    const review = await Review.create({ ...req.body, userId: req.user.id });
    const populatedReview = await Review.findById(review._id).populate('hotelId').populate('userId', 'name');

    await Notification.create({
      userId: req.user.id,
      message: `Your review for ${populatedReview.hotelId.name} has been published.`,
    });

    await Activity.create({
      userId: req.user.id,
      action: 'REVIEW_POSTED',
      details: { hotel: populatedReview.hotelId.name, rating: review.rating }
    });

    res.status(201).json(populatedReview);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateReview = async (req, res) => {
  try {
    const review = await Review.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!review) return res.status(404).json({ error: 'Review not found' });

    await Activity.create({
      userId: req.user.id,
      action: 'REVIEW_UPDATED',
      details: { reviewId: review._id, rating: review.rating }
    });

    res.json(review);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteReview = async (req, res) => {
  try {
    const review = await Review.findByIdAndDelete(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found' });

    await Activity.create({
      userId: req.user.id,
      action: 'REVIEW_DELETED',
      details: { reviewId: review._id, hotelId: review.hotelId }
    });

    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
