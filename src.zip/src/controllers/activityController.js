const Activity = require('../models/Activity');

exports.createActivity = async (req, res) => {
  try {
    const activity = new Activity({
      userId: req.user.id,
      action: req.body.action,
      details: req.body.details || {},
      ipAddress: req.ip
    });
    await activity.save();
    res.status(201).json({ message: 'Activity logged', activity });
  } catch (err) {
    res.status(500).json({ message: 'Failed to log activity', error: err.message });
  }
};

exports.getRecentActivities = async (req, res) => {
  try {
    const activities = await Activity.find()
      .populate('userId', 'name email')
      .sort({ createdAt: -1 })
      .limit(20)
      .lean();

    const formatted = activities.map(activity => ({
      id: activity._id,
      action: activity.action,
      user: activity.userId?.name || 'Anonymous',
      time: formatTimeAgo(activity.createdAt),
      status: getStatusFromAction(activity.action),
      details: activity.details
    }));

    res.json(formatted);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch activities', error: err.message });
  }
};

function formatTimeAgo(date) {
  const now = new Date();
  const diffMs = now - new Date(date);
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
}

function getStatusFromAction(action) {
  const statusMap = {
    'BOOKING_CREATED': 'completed',
    'BOOKING_CANCELLED': 'cancelled',
    'BOOKING_DELETED': 'cancelled',
    'REVIEW_POSTED': 'completed',
    'REVIEW_UPDATED': 'in-progress',
    'REVIEW_DELETED': 'cancelled',
    'FAVORITE_TOGGLED': 'completed',
    'FAVORITE_DELETED': 'cancelled',
    'LOGIN': 'completed',
    'LOGOUT': 'completed',
    'PROFILE_UPDATED': 'completed',
    'HOTEL_CREATED': 'completed',
    'HOTEL_UPDATED': 'in-progress',
    'HOTEL_DELETED': 'cancelled',
    'USER_REGISTERED': 'completed'
  };
  return statusMap[action] || 'info';
}
