const Booking = require('../models/Booking');
const Notification = require('../models/Notification');
const Activity = require('../models/Activity');
const Hotel = require('../models/Hotel');
const mongoose = require('mongoose');

exports.getBookings = async (req, res) => {
  try {
    const { page = 1, limit = 10, status, hotelId } = req.query;
    const isAdmin = req.user.role === 'admin';
    const query = isAdmin ? {} : { userId: new mongoose.Types.ObjectId(req.user.id) };

    if (status) query.status = status;
    if (hotelId) query.hotelId = hotelId;

    const bookings = await Booking.find(query)
      .populate('userId', 'name email')
      .populate('hotelId', 'name location')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    const total = await Booking.countDocuments(query);

    res.json({
      bookings,
      totalPages: Math.ceil(total / limit),
      currentPage: page
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createBooking = async (req, res) => {
  try {
    const userId = new mongoose.Types.ObjectId(req.user.id);
    const hotelId = new mongoose.Types.ObjectId(req.body.hotelId);
    const hotel = await Hotel.findById(hotelId);
    if (!hotel) {
      return res.status(404).json({ message: 'Hotel not found' });
    }

    const bookingData = {
      userId,
      hotelId,
      ...req.body
    };
    const booking = await Booking.create(bookingData);

    await Activity.create({
      action: 'BOOKING_CREATED',
      userId: booking.userId,
      bookingId: booking._id,
      details: {
        hotel: hotel.name,
        dates: req.body.dates
      }
    });

    await Notification.create({
      userId: booking.userId,
      type: 'booking_confirmation',
      title: 'Booking Confirmed',
      message: `Your booking for ${hotel.name} has been confirmed.`
    });

    const populatedBooking = await Booking.findById(booking._id).populate('userId hotelId');
    res.status(201).json(populatedBooking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('userId', 'name email')
      .populate('hotelId', 'name location');

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    res.json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status: 'cancelled' },
      { new: true }
    ).populate('userId hotelId');

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    await Activity.create({
      action: 'BOOKING_CANCELLED',
      userId: booking.userId,
      bookingId: booking._id,
      details: booking.hotelId.name
    });

    await Notification.create({
      userId: booking.userId,
      type: 'booking_cancelled',
      title: 'Booking Cancelled',
      message: `Your booking for ${booking.hotelId.name} has been cancelled.`
    });

    res.json(booking);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateBookingStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    ).populate('userId hotelId');

    res.json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    await Activity.create({
      action: 'BOOKING_DELETED',
      userId: req.user ? req.user.id : booking.userId,
      bookingId: booking._id,
      details: `${booking.hotelId ? booking.hotelId.name : 'Unknown hotel'} - Admin delete`
    });

    await Booking.findByIdAndDelete(req.params.id);

    res.json({ message: 'Booking deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
