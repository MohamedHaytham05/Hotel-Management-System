const User = require('../models/User');
const Hotel = require('../models/Hotel');
const Booking = require('../models/Booking');
const Review = require('../models/Review');

exports.getAdminStats = async (req, res) => {
  try {
    const [totalUsers, totalHotels, totalBookings, totalRevenue] = await Promise.all([
      User.countDocuments(),
      Hotel.countDocuments(),
      Booking.countDocuments(),
      Booking.aggregate([
        { $group: { _id: null, total: { $sum: '$price' } } }
      ])
    ]);

    res.json({
      totalHotels,
      totalUsers,
      activeBookings: totalBookings,
      monthlyRevenue: `$${totalRevenue[0]?.total || 0}`,
      totalReviews: await Review.countDocuments()
    });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch stats', error: err.message });
  }
};

exports.getBookingChartData = async (req, res) => {
  try {
    const { period = 'month' } = req.query;

    const match = {};
    if (period === 'today') {
      match.createdAt = { $gte: new Date(new Date().setHours(0,0,0,0)) };
    } else if (period === 'week') {
      match.createdAt = { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) };
    }

    const bookings = await Booking.aggregate([
      { $match: match },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const data = {
      completed: 0,
      pending: 0,
      cancelled: 0,
      'in-progress': 0
    };

    bookings.forEach(b => {
      data[b._id || 'pending'] = b.count;
    });

    res.json([
      { status: 'Completed', count: data.completed, color: 'bg-green-500' },
      { status: 'Pending', count: data.pending, color: 'bg-yellow-500' },
      { status: 'Cancelled', count: data.cancelled, color: 'bg-red-500' },
      { status: 'In Progress', count: data['in-progress'], color: 'bg-blue-500' }
    ]);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch booking chart data', error: err.message });
  }
};

exports.getRevenueChartData = async (req, res) => {
  try {
    const { period = '7days' } = req.query;

    let match = {};
    if (period === '7days') {
      match.createdAt = { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) };
    }

    const revenue = await Booking.aggregate([
      { $match: match },
      {
        $group: {
          _id: { $dateToString: { format: '%a', date: '$createdAt' } },
          amount: { $sum: '$price' }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json(revenue);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch revenue chart data', error: err.message });
  }
};
